﻿import pygame, random, sys, math, os
import asyncio

pygame.init()
W, H = 400, 600
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("ПрыжкоМания")
WHITE, BG, GREEN, BROWN, BLACK, ORANGE, CLOUD = (255,255,255), (170,210,245), (50,200,50), (139,69,19), (0,0,0), (255,165,0), (240,248,255)
BLUE, RED, GRAY = (30, 144, 255), (220, 20, 60), (180, 180, 180)
STONE_DARK = (85, 80, 78)
STONE_MID = (115, 108, 102)
STONE_LIGHT = (155, 148, 140)
STONE_HILITE = (185, 178, 170)
TRAJ_COLOR = (70, 70, 85)
clock = pygame.time.Clock()
FONT, BIG_FONT = pygame.font.SysFont("Arial", 20), pygame.font.SysFont("Arial", 32)
SMALL_FONT = pygame.font.SysFont("Arial", 15)
BOLD_SMALL_FONT = pygame.font.SysFont("Arial", 16, bold=True)

HIGHSCORE_FILE = "highscore.txt"
PROGRESS_FILE = "progress.txt"
MINIGAME_HIGHSCORE_FILES = {
    "lava": "highscore_lava.txt",
    "dark": "highscore_dark.txt",
    "vanish": "highscore_vanish.txt",
}

TOTAL_LEVELS = 50
WORKING_LEVELS = 25

LEVEL_INTRO_FREEZE = 13
LEVEL_INTRO_FREEZE_REPLACE = 15
LEVEL_INTRO_DANGER = 16
LEVEL_INTRO_SPIKE = 22
LEVEL_INTRO_MOVING = 19

# ======================== МИНИ ИГРЫ ========================
MINIGAME_LAVA_DELAY_MS = 0
MINIGAME_LAVA_START_SPEED = 0.16
MINIGAME_LAVA_START_MULT = 3.0
MINIGAME_LAVA_MAX_MULT = 30
MINIGAME_LAVA_RAMP_MS = 180000
MINIGAME_LAVA_GROWTH = 1.12
MINIGAME_DARK_RADIUS = 150
MINIGAME_DARK_FUEL_FULL_RADIUS = 170
MINIGAME_DARK_FUEL_EMPTY_RADIUS = 26
MINIGAME_DARK_MIN_RADIUS = 70
MINIGAME_DARK_FUEL_SECONDS = 60.0
MINIGAME_DARK_REFUEL_SECONDS = 25.0
MINIGAME_DARK_REFUEL_MIN_GAP = 500
MINIGAME_DARK_REFUEL_MAX_GAP = 800
MINIGAME_VANISH_DELAY_MS = 700
# ==========================================================

_static_stars_bg = None


def _get_stars_for_bg():
    global _static_stars_bg
    if _static_stars_bg is None:
        _static_stars_bg = [(random.randint(0, W), random.randint(0, H),
                             random.choice([1, 1, 1, 2])) for _ in range(70)]
    return _static_stars_bg


def load_high_score():
    try:
        if os.path.exists(HIGHSCORE_FILE):
            with open(HIGHSCORE_FILE, "r", encoding="utf-8") as f:
                return int(f.read().strip() or "0")
    except (ValueError, OSError):
        pass
    return 0


def save_high_score(value):
    try:
        with open(HIGHSCORE_FILE, "w", encoding="utf-8") as f:
            f.write(str(int(value)))
    except OSError:
        pass


def load_minigame_high_score(mode):
    path = MINIGAME_HIGHSCORE_FILES.get(mode)
    if not path:
        return 0
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return int(f.read().strip() or "0")
    except (ValueError, OSError):
        pass
    return 0


def save_minigame_high_score(mode, value):
    path = MINIGAME_HIGHSCORE_FILES.get(mode)
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(int(value)))
    except OSError:
        pass


def load_progress():
    try:
        if os.path.exists(PROGRESS_FILE):
            with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                return max(0, min(TOTAL_LEVELS, int(f.read().strip() or "0")))
    except (ValueError, OSError):
        pass
    return 0


def save_progress(value):
    try:
        with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
            f.write(str(int(value)))
    except OSError:
        pass


def draw_sun(surf):
    cx, cy = W - 52, 52
    t = pygame.time.get_ticks() * 0.001
    for i in range(12):
        ang = t * 0.6 + i * (2 * math.pi / 12)
        x1 = cx + math.cos(ang) * 30
        y1 = cy + math.sin(ang) * 30
        x2 = cx + math.cos(ang) * 42
        y2 = cy + math.sin(ang) * 42
        pygame.draw.line(surf, (255, 210, 80), (x1, y1), (x2, y2), 3)
    halo = pygame.Surface((110, 110), pygame.SRCALPHA)
    for i in range(20, 0, -1):
        r = int(55 * i / 20)
        a = int(4 + 6 * (20 - i) / 20)
        pygame.draw.circle(halo, (255, 220, 100, a), (55, 55), r)
    surf.blit(halo, (cx - 55, cy - 55))
    pygame.draw.circle(surf, (255, 200, 60), (cx, cy), 22)
    pygame.draw.circle(surf, (255, 230, 110), (cx - 4, cy - 4), 16)


def draw_moon_and_light(surf):
    cx, cy = W - 52, 52
    R = 240
    light = pygame.Surface((R * 2, R * 2), pygame.SRCALPHA)
    for i in range(28, 0, -1):
        rr = int(R * i / 28)
        a = int(2 + 3 * (28 - i) // 2)
        pygame.draw.circle(light, (200, 215, 245, a), (R, R), rr)
    surf.blit(light, (cx - R, cy - R))
    pygame.draw.circle(surf, (235, 235, 215), (cx, cy), 22)
    pygame.draw.circle(surf, (255, 255, 240), (cx - 5, cy - 4), 16)
    pygame.draw.circle(surf, (200, 200, 180), (cx + 7, cy + 3), 4)
    pygame.draw.circle(surf, (205, 205, 185), (cx - 8, cy + 5), 3)
    pygame.draw.circle(surf, (210, 210, 190), (cx + 2, cy - 8), 2)


def draw_oil_lamp(surf, cx, cy, side, fuel=1.0):
    cx = int(cx)
    cy = int(cy)
    fuel = max(0.0, min(1.0, fuel))

    if fuel > 0.0:
        t_now = pygame.time.get_ticks() * 0.004
        wobble = 1.0 + 0.05 * math.sin(t_now * 1.7) + 0.025 * math.sin(t_now * 3.1)
        R = int((8 + 22 * fuel) * wobble)
        if R > 2:
            glow = pygame.Surface((R * 2, R * 2), pygame.SRCALPHA)
            for i in range(1, 11):
                r = int(R * i / 10)
                a = int((10 + 30 * fuel) * (1 - i / 10))
                pygame.draw.circle(glow, (255, 210, 120, a), (R, R), r)
            surf.blit(glow, (cx - R, cy - R))

    tilt = 4 if side > 0 else (-4 if side < 0 else 0)

    base_w = 14
    base_h = 4
    pygame.draw.rect(surf, (110, 80, 40),
                     (cx - base_w // 2, cy + 10, base_w, base_h),
                     border_radius=2)
    pygame.draw.rect(surf, (60, 40, 20),
                     (cx - base_w // 2, cy + 10, base_w, base_h), 1,
                     border_radius=2)

    tank_w = 12
    tank_h = 8
    tank_y = cy + 3
    pygame.draw.rect(surf, (200, 150, 60),
                     (cx - tank_w // 2, tank_y, tank_w, tank_h),
                     border_radius=3)
    pygame.draw.rect(surf, (120, 80, 25),
                     (cx - tank_w // 2, tank_y, tank_w, tank_h), 1,
                     border_radius=3)
    pygame.draw.line(surf, (255, 220, 150),
                     (cx - tank_w // 2 + 2, tank_y + 1),
                     (cx - tank_w // 2 + 2, tank_y + tank_h - 2), 1)

    glass_top = cy - 8
    glass_bot = cy + 3
    pygame.draw.polygon(surf, (255, 200, 90),
                        [(cx - 5, glass_bot),
                         (cx - 4, glass_top),
                         (cx + 4, glass_top),
                         (cx + 5, glass_bot)])
    pygame.draw.polygon(surf, (120, 80, 25),
                        [(cx - 5, glass_bot),
                         (cx - 4, glass_top),
                         (cx + 4, glass_top),
                         (cx + 5, glass_bot)], 1)

    if fuel > 0.02:
        t = pygame.time.get_ticks() * 0.01
        flick = math.sin(t) * 1.2 * fuel
        flame_h = 4 + 6 * fuel
        flame_cx = cx + tilt * 0.2
        flame_cy = cy - 4
        pts = [(flame_cx + flick, flame_cy - flame_h),
               (flame_cx - 3 * fuel, flame_cy + 1),
               (flame_cx + 3 * fuel, flame_cy + 1)]
        pygame.draw.polygon(surf, (255, 170, 40), pts)
        pygame.draw.polygon(surf, (255, 240, 180),
                            [(flame_cx + flick * 0.5, flame_cy - flame_h * 0.6),
                             (flame_cx - 1.5 * fuel, flame_cy + 1),
                             (flame_cx + 1.5 * fuel, flame_cy + 1)])

    pygame.draw.rect(surf, (90, 70, 40),
                     (cx - 4, glass_top - 3, 8, 3),
                     border_radius=1)

    handle_x = cx + tilt
    pygame.draw.arc(surf, (90, 70, 40),
                    (handle_x - 6, glass_top - 10, 12, 12),
                    math.pi, 2 * math.pi, 2)

    pygame.draw.line(surf, (80, 60, 30),
                     (cx, glass_top + 1), (cx, glass_top - 1), 2)


def draw_fuel_can(surf, cx, cy):
    cx = int(cx)
    cy = int(cy)
    w, h = 18, 14
    x = cx - w // 2
    y = cy - h
    pygame.draw.rect(surf, (190, 50, 40), (x, y, w, h), border_radius=3)
    pygame.draw.rect(surf, (90, 20, 15), (x, y, w, h), 1, border_radius=3)
    pygame.draw.line(surf, (240, 120, 100), (x + 2, y + 2), (x + 2, y + h - 2), 1)
    pygame.draw.rect(surf, (60, 60, 60), (x + w - 6, y - 3, 5, 4), border_radius=1)
    pygame.draw.arc(surf, (60, 60, 60),
                    (x + 2, y - 5, w - 8, 8),
                    0, math.pi, 2)
    pygame.draw.circle(surf, (255, 220, 120), (cx, cy - h // 2 - 1), 3)
    pygame.draw.polygon(surf, (255, 220, 120),
                        [(cx - 2, cy - h // 2 - 1),
                         (cx + 2, cy - h // 2 - 1),
                         (cx, cy - h // 2 - 6)])


def draw_danger_glow(surf, p):
    cx = p.x + p.w // 2
    cy = p.y + p.h // 2

    t_now = pygame.time.get_ticks() * 0.004
    wobble = 1.0 + 0.09 * math.sin(t_now * 2.3) + 0.045 * math.sin(t_now * 4.7)
    jx = (random.random() - 0.5) * 2.0
    jy = (random.random() - 0.5) * 2.0

    oval_w = int((p.w + 62) * wobble)
    oval_h = int((p.h + 48) * wobble)
    if oval_w < 4 or oval_h < 4:
        return
    glow = pygame.Surface((oval_w, oval_h), pygame.SRCALPHA)

    steps = 18
    for i in range(steps, 0, -1):
        t = i / steps
        a = int(34 * (1 - t) ** 1.5)
        if a <= 0:
            continue
        rx = int(oval_w * 0.5 * t)
        ry = int(oval_h * 0.5 * t)
        if rx <= 0 or ry <= 0:
            continue
        pygame.draw.ellipse(glow, (150, 210, 255, a),
                            (oval_w // 2 - rx, oval_h // 2 - ry, rx * 2, ry * 2))

    surf.blit(glow, (cx - oval_w // 2 + jx, cy - oval_h // 2 + jy))


def draw_star_field_static(surf, stars, t):
    for i, (sx, sy, sr) in enumerate(stars):
        tw = 0.6 + 0.4 * math.sin(t * 1.5 + i)
        a = int(120 + 120 * tw)
        a = max(0, min(255, a))
        c = (a, a, min(255, a + 40))
        if sr == 1:
            surf.set_at((sx, sy), c)
        else:
            pygame.draw.circle(surf, c, (sx, sy), sr)


def _draw_dark_bg(surf):
    surf.fill((10, 12, 26))
    draw_star_field_static(surf, _get_stars_for_bg(), pygame.time.get_ticks() * 0.001)
    draw_moon_and_light(surf)


def draw_glow_text(surf, text, font, color, cx, cy):
    base = font.render(text, True, color)
    shadow = font.render(text, True, (0, 0, 0))
    rect = base.get_rect(center=(cx, cy))
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            surf.blit(shadow, (rect.x + dx, rect.y + dy))
    surf.blit(base, rect)


def _theme_text(text, font, dark, x, y,
                light_color=(200, 230, 255), dark_color=BLACK, center=True):
    if dark:
        draw_glow_text(screen, text, font, light_color, x, y)
    else:
        if center:
            show_text(text, font, dark_color, x, y, center=True)
        else:
            show_text(text, font, dark_color, x, y)


def draw_lock(surf, cx, cy, size=14, color=(240, 240, 240)):
    body_w = size
    body_h = int(size * 0.8)
    bx = cx - body_w // 2
    by = cy - body_h // 2
    pygame.draw.rect(surf, color, (bx, by, body_w, body_h), border_radius=2)
    pygame.draw.rect(surf, (60, 60, 60), (bx, by, body_w, body_h), 1, border_radius=2)
    arc_r = body_w // 2 - 1
    arc_rect = pygame.Rect(cx - arc_r, by - arc_r - 1, arc_r * 2, arc_r * 2)
    pygame.draw.arc(surf, color, arc_rect, 0, math.pi, 3)
    pygame.draw.circle(surf, (60, 60, 60), (cx, cy + 2), 2)


def draw_star_icon(surf, cx, cy, r=8, fill=(255, 220, 70), outline=(160, 110, 10)):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rr = r if i % 2 == 0 else r * 0.42
        pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
    pygame.draw.polygon(surf, fill, pts)
    pygame.draw.polygon(surf, outline, pts, 1)


def draw_broken_flag(surf, cx, cy, scale=1.0):
    s = scale
    pole_top = (cx + int(12 * s), cy - int(38 * s))
    pole_bottom = (cx - int(8 * s), cy + int(30 * s))
    pygame.draw.line(surf, (90, 90, 90), pole_bottom, pole_top,
                     max(2, int(5 * s)))
    pygame.draw.circle(surf, (60, 60, 60), pole_top, max(2, int(3 * s)))
    p1 = pole_top
    p2 = (pole_top[0] + int(26 * s), pole_top[1] + int(6 * s))
    p3 = (pole_top[0] + int(20 * s), pole_top[1] + int(20 * s))
    p4 = (pole_top[0] + int(2 * s), pole_top[1] + int(16 * s))
    pygame.draw.polygon(surf, (220, 30, 40), [p1, p2, p3, p4])
    pygame.draw.polygon(surf, (90, 20, 25), [p1, p2, p3, p4], 2)
    q1 = (pole_top[0] + int(14 * s), pole_top[1] + int(30 * s))
    q2 = (pole_top[0] + int(36 * s), pole_top[1] + int(38 * s))
    q3 = (pole_top[0] + int(30 * s), pole_top[1] + int(48 * s))
    q4 = (pole_top[0] + int(14 * s), pole_top[1] + int(42 * s))
    pygame.draw.polygon(surf, (180, 25, 35), [q1, q2, q3, q4])
    pygame.draw.polygon(surf, (90, 20, 25), [q1, q2, q3, q4], 2)


def draw_outlined_text(surf, text, font, text_color, outline_color, cx, cy):
    text_surf = font.render(text, True, text_color)
    outline_surf = font.render(text, True, outline_color)
    rect = text_surf.get_rect(center=(cx, cy))
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            surf.blit(outline_surf, (rect.x + dx, rect.y + dy))
    surf.blit(text_surf, rect)


_UNSAFE_RESPAWN_TYPES = ("cloud", "break", "spike", "danger", "freeze", "fuel")


def choose_respawn_target(platforms, last_stood, last_stood_y):
    if (last_stood is not None and last_stood in platforms
            and not last_stood.broken
            and last_stood.type not in _UNSAFE_RESPAWN_TYPES):
        return last_stood

    if last_stood_y is not None:
        safe_above = [p for p in platforms
                      if not p.broken
                      and p.type not in _UNSAFE_RESPAWN_TYPES
                      and p.y < last_stood_y - 5]
        if safe_above:
            return max(safe_above, key=lambda p: p.y)
        safe_all = [p for p in platforms
                    if not p.broken
                    and p.type not in _UNSAFE_RESPAWN_TYPES]
        if safe_all:
            return max(safe_all, key=lambda p: p.y)
        return None

    safe_all = [p for p in platforms
                if not p.broken
                and p.type not in _UNSAFE_RESPAWN_TYPES]
    if not safe_all:
        return None
    return max(safe_all, key=lambda p: p.y)


# ======================== КОНФЕТТИ ========================
class Confetti:
    COLORS = [
        (255, 80, 80), (255, 160, 40), (255, 230, 60),
        (100, 220, 100), (60, 180, 255), (150, 90, 255),
        (255, 100, 200), (255, 255, 255), (255, 200, 100),
    ]
    __slots__ = ("x", "y", "vx", "vy", "rot", "rot_speed", "w", "h",
                 "color", "life", "max_life", "shape", "sway_phase", "sway_speed")

    def __init__(self, x, y, vx=None, vy=None):
        self.x = x
        self.y = y
        if vx is None:
            vx = random.uniform(-3.5, 3.5)
        if vy is None:
            vy = random.uniform(-9.0, -4.0)
        self.vx = vx
        self.vy = vy
        self.rot = random.uniform(0, 360)
        self.rot_speed = random.uniform(-12, 12)
        self.w = random.randint(3, 6)
        self.h = random.randint(2, 4)
        self.color = random.choice(self.COLORS)
        self.life = random.randint(1600, 2600)
        self.max_life = self.life
        self.shape = random.choice(["rect", "circle", "strip"])
        self.sway_phase = random.uniform(0, math.pi * 2)
        self.sway_speed = random.uniform(0.05, 0.12)

    def update(self, dt):
        k = dt / 16.0
        self.vy += 0.28 * k
        self.sway_phase += self.sway_speed * k
        sway = math.sin(self.sway_phase) * 0.6
        self.x += (self.vx + sway) * k
        self.y += self.vy * k
        self.vx *= 0.995
        self.rot += self.rot_speed * k
        self.life -= dt

    def draw(self, surf):
        alpha = max(0, min(255, int(255 * self.life / self.max_life)))
        if alpha <= 0:
            return
        if self.shape == "circle":
            s = pygame.Surface((self.w * 2, self.w * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.color, alpha), (self.w, self.w), self.w)
            surf.blit(s, (self.x - self.w, self.y - self.w))
        elif self.shape == "strip":
            s = pygame.Surface((self.w * 2, self.h * 4), pygame.SRCALPHA)
            pygame.draw.rect(s, (*self.color, alpha),
                             (self.w // 2, 0, self.w, self.h * 4))
            rotated = pygame.transform.rotate(s, self.rot)
            rect = rotated.get_rect(center=(self.x, self.y))
            surf.blit(rotated, rect.topleft)
        else:
            s = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
            pygame.draw.rect(s, (*self.color, alpha), (0, 0, self.w, self.h))
            rotated = pygame.transform.rotate(s, self.rot)
            rect = rotated.get_rect(center=(self.x, self.y))
            surf.blit(rotated, rect.topleft)


def spawn_confetti_burst(confetti_list, cx, cy, count=90):
    for _ in range(count):
        ox = random.uniform(-8, 8)
        oy = random.uniform(-8, 8)
        c = Confetti(cx + ox, cy + oy)
        c.vx = random.uniform(-5.0, 5.0)
        c.vy = random.uniform(-12.0, -3.0)
        confetti_list.append(c)


def update_and_draw_confetti(confetti_list, dt, surf):
    for c in confetti_list[:]:
        c.update(dt)
        if c.life <= 0 or c.y > H + 40:
            confetti_list.remove(c)
            continue
        c.draw(surf)
# ==========================================================


class Button:
    def __init__(self, text, cx, cy, w=220, h=55, base_color=(70, 160, 90)):
        self.text = text
        self.rect = pygame.Rect(0, 0, w, h)
        self.rect.center = (cx, cy)
        self.base_color = base_color
        self.hover_color = tuple(min(255, c + 45) for c in base_color)
        self.press_color = tuple(max(0, c - 40) for c in base_color)
        self.hover_t = 0.0
        self.press_t = 0.0
        self.hovered = False
        self.pressed = False
        self.clicked = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.pressed = True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.pressed and self.rect.collidepoint(event.pos):
                self.clicked = True
            self.pressed = False

    def update(self, dt):
        target_h = 1.0 if self.hovered else 0.0
        target_p = 1.0 if (self.pressed and self.hovered) else 0.0
        speed = dt / 120.0
        self.hover_t += (target_h - self.hover_t) * min(1.0, speed * 2.5)
        self.press_t += (target_p - self.press_t) * min(1.0, speed * 3.5)

    def reset_state(self):
        self.hover_t = 0.0
        self.press_t = 0.0
        self.hovered = False
        self.pressed = False
        self.clicked = False

    def draw(self, surf, font):
        scale = 1.0 + 0.06 * self.hover_t - 0.11 * self.press_t

        def lerp(a, b, t):
            return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

        col = lerp(self.base_color, self.hover_color, self.hover_t)
        col = lerp(col, self.press_color, self.press_t)
        w = int(self.rect.w * scale)
        h = int(self.rect.h * scale)
        rect = pygame.Rect(0, 0, w, h)
        rect.center = self.rect.center

        shadow_off = int(4 + 4 * self.hover_t - 4 * self.press_t)
        shadow = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(shadow, (0, 0, 0, 90), (0, 0, w, h), border_radius=12)
        surf.blit(shadow, (rect.x + 2, rect.y + shadow_off))

        pygame.draw.rect(surf, col, rect, border_radius=12)
        border_col = lerp((0, 0, 0), (255, 255, 255), self.hover_t * 0.7)
        pygame.draw.rect(surf, border_col, rect, 3, border_radius=12)

        gloss = pygame.Surface((w - 8, h // 2), pygame.SRCALPHA)
        pygame.draw.rect(gloss, (255, 255, 255, int(45 + 40 * self.hover_t)),
                         (0, 0, w - 8, h // 2), border_radius=10)
        surf.blit(gloss, (rect.x + 4, rect.y + 4))

        if self.text:
            lbl = font.render(self.text, True, (255, 255, 255))
            surf.blit(lbl, lbl.get_rect(center=rect.center))

        if self.press_t > 0.05:
            flash = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.rect(flash, (255, 255, 255, int(120 * self.press_t)),
                             (0, 0, w, h), border_radius=12)
            surf.blit(flash, rect.topleft)


class TextLink:
    def __init__(self, text, cx, cy, font, color=(0, 0, 0),
                 hover_color=(70, 70, 70), underline_on_hover=True):
        self.text = text
        self.font = font
        self.color = color
        self.hover_color = hover_color
        self.underline_on_hover = underline_on_hover
        self.rendered_normal = font.render(text, True, color)
        self.rendered_hover = font.render(text, True, hover_color)
        self.rect = self.rendered_normal.get_rect(center=(cx, cy))
        self.hover_t = 0.0
        self.hovered = False
        self.clicked = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.clicked = True

    def update(self, dt):
        target = 1.0 if self.hovered else 0.0
        self.hover_t += (target - self.hover_t) * min(1.0, dt / 80.0)

    def draw(self, surf):
        if self.hover_t > 0.5:
            surf.blit(self.rendered_hover, self.rect.topleft)
            if self.underline_on_hover:
                y = self.rect.bottom + 1
                pygame.draw.line(surf, self.hover_color,
                                 (self.rect.left, y), (self.rect.right, y), 1)
        else:
            surf.blit(self.rendered_normal, self.rect.topleft)


def draw_trophy(surf, cx, cy, scale=1.0):
    gold = (255, 215, 0)
    gold_dark = (180, 130, 10)
    gold_light = (255, 245, 150)
    s = scale
    top_w = 28 * s
    bot_w = 15 * s
    cup_h = 24 * s
    top_y = cy - 16 * s
    bot_y = top_y + cup_h
    pts = [(cx - top_w / 2, top_y), (cx + top_w / 2, top_y),
           (cx + bot_w / 2, bot_y), (cx - bot_w / 2, bot_y)]
    pygame.draw.polygon(surf, gold, pts)
    pygame.draw.polygon(surf, gold_dark, pts, max(1, int(2 * s)))
    pygame.draw.line(surf, gold_light,
                     (cx - top_w / 2 + 3 * s, top_y + 2 * s),
                     (cx - bot_w / 2 + 2 * s, bot_y - 4 * s),
                     max(1, int(2 * s)))
    handle_r = 7 * s
    handle_thick = max(2, int(3 * s))
    pygame.draw.arc(surf, gold,
                    (cx - top_w / 2 - handle_r * 2, top_y + 3 * s, handle_r * 2, handle_r * 2),
                    -math.pi / 2, math.pi / 2, handle_thick)
    pygame.draw.arc(surf, gold,
                    (cx + top_w / 2, top_y + 3 * s, handle_r * 2, handle_r * 2),
                    math.pi / 2, 3 * math.pi / 2, handle_thick)
    stem_w = 5 * s
    stem_h = 7 * s
    pygame.draw.rect(surf, gold, (cx - stem_w / 2, bot_y, stem_w, stem_h))
    pygame.draw.rect(surf, gold_dark, (cx - stem_w / 2, bot_y, stem_w, stem_h),
                     max(1, int(1 * s)))
    base_w = 20 * s
    base_h = 5 * s
    base_y = bot_y + stem_h
    pygame.draw.rect(surf, gold, (cx - base_w / 2, base_y, base_w, base_h))
    pygame.draw.rect(surf, gold_dark, (cx - base_w / 2, base_y, base_w, base_h),
                     max(1, int(1 * s)))
    pygame.draw.line(surf, gold_light,
                     (cx - base_w / 2 + 2 * s, base_y + 1 * s),
                     (cx + base_w / 2 - 2 * s, base_y + 1 * s),
                     max(1, int(1 * s)))


class TrophyButton(Button):
    def __init__(self, cx, cy, size=56):
        super().__init__("", cx, cy, w=size, h=size, base_color=(200, 160, 60))
        self.size = size

    def draw(self, surf, font):
        super().draw(surf, font)
        scale = 1.0 + 0.06 * self.hover_t - 0.11 * self.press_t
        draw_trophy(surf, self.rect.centerx, self.rect.centery, scale=0.75 * scale)


high_score = load_high_score()

MAX_PARTICLES_TOTAL = 120
MAX_DANGER_PLATFORMS = 3
MAX_CLOUD_PLATFORMS = 3
DANGER_SAFE_GAP = 78
REF_W = 80.0
BASE_CLOUD_SPEED = 0.26
MIN_CLOUD_SPEED = 0.10
DIFFICULTY_MAX_SCORE = 20000
BASE_MIN_GAP = 65
BASE_MAX_GAP = 85
FINAL_MIN_GAP = 100
FINAL_MAX_GAP = 125
MOVING_START_SCORE = 4000
MOVING_REPLACE_CHANCE = 0.10
MOVING_SPEED_MULT_AT_20K = 3.0
MOVING_RANGE_MIN = 40
MOVING_RANGE_MAX = 65
BASE_MOVING_SPEED = 1.5
SPIKE_START_SCORE = 5000
SPIKE_H = 13
MAX_RESPAWNS = 3

FREEZE_REPLACE_START_SCORE = 5000
FREEZE_REPLACE_CHANCE = 0.08
SPRING_CHANCE = 0.07

INFINITE_FREEZE_CHANCE = 0.18

FLAT_DANGER_CHANCE = 0.03
FLAT_SPIKE_CHANCE = 0.05

SPRING_HIT_PAD = 10


def platform_gap_range(score):
    t = min(1.0, score / DIFFICULTY_MAX_SCORE)
    min_gap = int(BASE_MIN_GAP + (FINAL_MIN_GAP - BASE_MIN_GAP) * t)
    max_gap = int(BASE_MAX_GAP + (FINAL_MAX_GAP - BASE_MAX_GAP) * t)
    MAX_REACHABLE_GAP = 140
    min_gap = min(min_gap, MAX_REACHABLE_GAP - 10)
    max_gap = min(max_gap, MAX_REACHABLE_GAP)
    return min_gap, max_gap


def danger_chance(score):
    if score < 3000: return 0.0
    if score < 4000: return 0.03
    if score >= 20000: return 0.20
    t = (score - 4000) / 16000.0
    return 0.03 + 0.17 * t


def spike_chance(score):
    if score < SPIKE_START_SCORE: return 0.0
    if score >= 20000: return 0.30
    t = (score - SPIKE_START_SCORE) / 15000.0
    return 0.05 + 0.25 * t


def moving_speed_mult(score):
    if score < MOVING_START_SCORE: return 1.0
    if score >= DIFFICULTY_MAX_SCORE: return MOVING_SPEED_MULT_AT_20K
    t = (score - MOVING_START_SCORE) / (DIFFICULTY_MAX_SCORE - MOVING_START_SCORE)
    return 1.0 + (MOVING_SPEED_MULT_AT_20K - 1.0) * t


def freeze_replace_chance(score):
    if score < FREEZE_REPLACE_START_SCORE:
        return 0.0
    return FREEZE_REPLACE_CHANCE


_snowflake_cache = {}


def _draw_snowflake_raw(surf, cx, cy, size, color):
    for i in range(6):
        ang = math.pi / 3 * i
        ex = cx + math.cos(ang) * size
        ey = cy + math.sin(ang) * size
        pygame.draw.line(surf, color, (cx, cy), (ex, ey), 1)
        for t in (0.5, 0.75):
            bx = cx + math.cos(ang) * size * t
            by = cy + math.sin(ang) * size * t
            for side in (-1, 1):
                ba = ang + side * math.pi / 3
                bx2 = bx + math.cos(ba) * size * 0.35
                by2 = by + math.sin(ba) * size * 0.35
                pygame.draw.line(surf, color, (bx, by), (bx2, by2), 1)


def draw_snowflake(surf, cx, cy, size, color):
    key = (int(size), color)
    if key not in _snowflake_cache:
        pad = 2
        s = pygame.Surface((int(size) * 2 + pad * 2, int(size) * 2 + pad * 2), pygame.SRCALPHA)
        _draw_snowflake_raw(s, int(size) + pad, int(size) + pad, size, color)
        _snowflake_cache[key] = (s, pad, int(size))
    s, pad, isz = _snowflake_cache[key]
    surf.blit(s, (cx - isz - pad, cy - isz - pad))


_gear_frames_cache = {}


def _make_gear_frame(angle, r=5):
    size = (r + 6) * 2
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    cx = cy = size // 2
    teeth = 8
    tooth_len = 3
    for i in range(teeth):
        a = angle + i * (2 * math.pi / teeth)
        x1 = cx + math.cos(a) * (r - 1); y1 = cy + math.sin(a) * (r - 1)
        x2 = cx + math.cos(a) * (r + tooth_len); y2 = cy + math.sin(a) * (r + tooth_len)
        pygame.draw.line(s, STONE_DARK, (int(x1), int(y1)), (int(x2), int(y2)), 3)
    pygame.draw.circle(s, STONE_MID, (cx, cy), r)
    pygame.draw.circle(s, STONE_LIGHT, (cx - 1, cy - 1), r - 1)
    pygame.draw.circle(s, STONE_DARK, (cx, cy), r, 1)
    for i in range(4):
        a = angle + i * (math.pi / 2)
        x1 = cx + math.cos(a); y1 = cy + math.sin(a)
        x2 = cx + math.cos(a) * (r - 1); y2 = cy + math.sin(a) * (r - 1)
        pygame.draw.line(s, STONE_DARK, (int(x1), int(y1)), (int(x2), int(y2)), 1)
    pygame.draw.circle(s, STONE_DARK, (cx, cy), 2)
    pygame.draw.circle(s, STONE_HILITE, (cx - 1, cy - 1), 1)
    return s


def _get_gear_frames(r=5, n_frames=12):
    key = (r, n_frames)
    if key in _gear_frames_cache:
        return _gear_frames_cache[key]
    frames = [_make_gear_frame(i * (2 * math.pi / n_frames), r) for i in range(n_frames)]
    _gear_frames_cache[key] = frames
    return frames


def _triangle_frac(phase):
    t = phase % (2 * math.pi)
    if t < math.pi: return t / math.pi
    return 2 - t / math.pi


class BackgroundCloud:
    def __init__(self, others=None):
        self.shape = random.choice(["classic", "wide", "tall", "bumpy", "huge"])
        if self.shape == "classic":
            self.w = random.randint(50, 70); self.h = random.randint(22, 30)
        elif self.shape == "wide":
            self.w = random.randint(80, 110); self.h = random.randint(24, 32)
        elif self.shape == "tall":
            self.w = random.randint(45, 60); self.h = random.randint(32, 42)
        elif self.shape == "huge":
            self.w = random.randint(95, 125); self.h = random.randint(30, 40)
        else:
            self.w = random.randint(60, 80); self.h = random.randint(22, 30)
        ratio = REF_W / max(20.0, self.w)
        size_factor = ratio ** 1.4
        jitter = random.uniform(0.92, 1.08)
        self.spd = BASE_CLOUD_SPEED * size_factor * jitter
        self.spd = max(MIN_CLOUD_SPEED, min(self.spd, 1.2))
        r0, g0, b0 = CLOUD
        shift = random.randint(-15, 30)
        self.color = (max(180, min(255, r0 + shift)),
                      max(180, min(255, g0 + shift)),
                      max(180, min(255, b0 + shift)))
        self.puffs = self._make_puffs()
        self.x, self.y = 0, 0
        self._place(others, initial=True)
        self._surface = None
        self._pad_l = 2; self._pad_t = 2
        self._render_surface()

    def _render_surface(self):
        w, h = self.w, self.h
        pad_l = pad_r = pad_t = pad_b = 2
        for (px, py, pr) in self.puffs:
            pad_l = max(pad_l, int(pr - px) + 2)
            pad_r = max(pad_r, int(pr - (w - px)) + 2)
            pad_t = max(pad_t, int(pr - py) + 2)
            pad_b = max(pad_b, int(pr - (h - py)) + 2)
        pad_l = max(0, pad_l); pad_r = max(0, pad_r)
        pad_t = max(0, pad_t); pad_b = max(0, pad_b)
        self._pad_l = pad_l; self._pad_t = pad_t
        s = pygame.Surface((w + pad_l + pad_r, h + pad_t + pad_b), pygame.SRCALPHA)
        c = self.color
        ox, oy = pad_l, pad_t
        pygame.draw.rect(s, c, (ox + 4, oy + h // 2, w - 8, h // 2))
        for (px, py, pr) in self.puffs:
            pygame.draw.circle(s, c, (int(ox + px), int(oy + py)), int(pr))
        self._surface = s

    def _make_puffs(self):
        w, h = self.w, self.h
        if self.shape == "classic":
            return [(w*0.15, h*0.65, h*0.45), (w*0.35, h*0.40, h*0.55), (w*0.55, h*0.30, h*0.65),
                    (w*0.75, h*0.40, h*0.55), (w*0.90, h*0.65, h*0.45), (w*0.25, h*0.55, h*0.55),
                    (w*0.65, h*0.55, h*0.55)]
        elif self.shape == "wide":
            puffs = []
            for i in range(7):
                t = i / 6
                hh = h * (0.4 + 0.35 * math.sin(t * math.pi))
                puffs.append((w * t, h - hh, hh))
            return puffs
        elif self.shape == "tall":
            return [(w*0.5, h*0.80, h*0.45), (w*0.5, h*0.55, h*0.42), (w*0.5, h*0.32, h*0.35),
                    (w*0.25, h*0.70, h*0.38), (w*0.75, h*0.70, h*0.38)]
        elif self.shape == "huge":
            return [(w*0.10, h*0.70, h*0.42), (w*0.25, h*0.50, h*0.52), (w*0.42, h*0.38, h*0.60),
                    (w*0.58, h*0.35, h*0.62), (w*0.75, h*0.50, h*0.52), (w*0.90, h*0.70, h*0.42),
                    (w*0.35, h*0.65, h*0.48), (w*0.65, h*0.65, h*0.48)]
        else:
            return [(w*0.15, h*0.60, h*0.42), (w*0.30, h*0.40, h*0.48), (w*0.50, h*0.35, h*0.52),
                    (w*0.70, h*0.42, h*0.46), (w*0.85, h*0.62, h*0.40), (w*0.40, h*0.62, h*0.50),
                    (w*0.62, h*0.60, h*0.46)]

    def _place(self, others, initial=False):
        for _ in range(25):
            if initial:
                x, y = random.randint(-50, W), random.randint(0, H - 200)
            else:
                x, y = random.randint(-50, W), random.randint(-120, -40)
            if others is None:
                self.x, self.y = x, y; return
            ok = True
            for o in others:
                if o is self: continue
                min_dx = (self.w + o.w) / 2 * 0.85
                min_dy = (self.h + o.h) / 2 * 0.85
                if abs(x - o.x) < min_dx and abs(y - o.y) < min_dy:
                    ok = False; break
            if ok:
                self.x, self.y = x, y; return
        if initial:
            self.x, self.y = random.randint(-50, W), random.randint(0, H - 200)
        else:
            self.x, self.y = random.randint(-50, W), random.randint(-120, -40)

    def update(self, dy, others=None):
        self.x += self.spd
        self.y += dy * 0.5
        if self.x > W or self.y > H:
            self._place(others, initial=False)

    def draw(self, surf):
        surf.blit(self._surface, (int(self.x) - self._pad_l, int(self.y) - self._pad_t))


_particle_surf_cache = {}


def _get_particle_surf(radius):
    key = int(radius)
    if key not in _particle_surf_cache:
        size = key * 2 + 4
        _particle_surf_cache[key] = pygame.Surface((size, size), pygame.SRCALPHA)
    return _particle_surf_cache[key]


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "r", "life", "max_life", "gen", "split_done")

    def __init__(self, x, y, vx, vy, r, life, gen):
        self.x = x; self.y = y; self.vx = vx; self.vy = vy
        self.r = r; self.life = life; self.max_life = life
        self.gen = gen; self.split_done = False

    def update(self, dt):
        self.x += self.vx * dt / 16.0
        self.y += self.vy * dt / 16.0
        self.vy += 0.05 * dt / 16.0
        self.vx *= 0.98
        self.life -= dt

    def draw(self, surf):
        alpha = max(0, int(255 * self.life / self.max_life))
        if alpha <= 0 or self.r < 0.5: return
        r = int(self.r)
        s = _get_particle_surf(r)
        s.fill((0, 0, 0, 0))
        pygame.draw.circle(s, (*CLOUD, alpha), (r + 2, r + 2), r)
        surf.blit(s, (self.x - self.r - 2, self.y - self.r - 2))


class Frog:
    def __init__(self):
        self.w, self.h = 30, 30
        self.x, self.y = W // 2 - 15, H - 130
        self.vy, self.gravity, self.jump_power = 0, 0.5, -13
        self.jumps_left = 1
        self.ability_active = False
        self.ability_timer = 0
        self.cooldown = 0
        self.spring_timer = 0
        self.spring_platform = None
        self.freeze_timer = 0
        self.dying = False
        self.death_timer = 0
        self.standing_platform = None
        self.standing_offset_x = 0.0
        self.death_kind = None
        self.knockback_vx = 0.0
        self.knockback_vy = 0.0
        self._frog_pad = 4
        self._frog_surface = self._render_base_frog()
        self.has_lamp = False
        self.lamp_offset = 22.0
        self.lamp_target_offset = 22.0
        self.lamp_y = -6
        self.lamp_fuel_seconds = MINIGAME_DARK_FUEL_SECONDS

    def _render_base_frog(self):
        w, h = self.w, self.h
        pad = 4
        s = pygame.Surface((w + 2 * pad, h + 2 * pad), pygame.SRCALPHA)
        ox, oy = pad, pad
        pygame.draw.ellipse(s, (30, 150, 30), (ox - 3, oy + h - 8, 10, 8))
        pygame.draw.ellipse(s, (30, 150, 30), (ox + w - 7, oy + h - 8, 10, 8))
        pygame.draw.ellipse(s, GREEN, (ox, oy + 3, w, h - 2))
        pygame.draw.ellipse(s, (120, 225, 120), (ox + 6, oy + 14, w - 12, h - 12))
        pygame.draw.circle(s, GREEN, (ox + 8, oy + 4), 6)
        pygame.draw.circle(s, GREEN, (ox + w - 8, oy + 4), 6)
        pygame.draw.circle(s, WHITE, (ox + 8, oy + 4), 4)
        pygame.draw.circle(s, WHITE, (ox + w - 8, oy + 4), 4)
        pygame.draw.circle(s, BLACK, (ox + 9, oy + 5), 2)
        pygame.draw.circle(s, BLACK, (ox + w - 9, oy + 5), 2)
        pygame.draw.circle(s, WHITE, (ox + 10, oy + 4), 1)
        pygame.draw.circle(s, WHITE, (ox + w - 8, oy + 4), 1)
        pygame.draw.arc(s, (20, 90, 20), (ox + 8, oy + 12, w - 16, 10), math.pi, 2 * math.pi, 2)
        pygame.draw.ellipse(s, (30, 150, 30), (ox + 4, oy + h - 4, 7, 5))
        pygame.draw.ellipse(s, (30, 150, 30), (ox + w - 11, oy + h - 4, 7, 5))
        return s

    def move(self):
        keys = pygame.key.get_pressed()
        speed = 5
        if self.freeze_timer > 0: speed = 5 / 1.3
        moving_left = keys[pygame.K_a]
        moving_right = keys[pygame.K_d]
        if self.has_lamp:
            if moving_left and not moving_right:
                self.lamp_target_offset = -22.0
            elif moving_right and not moving_left:
                self.lamp_target_offset = 22.0
            self.lamp_offset += (self.lamp_target_offset - self.lamp_offset) * 0.25
        if moving_left: self.x -= speed
        if moving_right: self.x += speed
        if self.x < -self.w: self.x = W
        elif self.x > W: self.x = -self.w
        self.vy += self.gravity
        self.y += self.vy

    def get_lamp_pos(self):
        cx = self.x + self.w / 2 + self.lamp_offset
        cy = self.y + self.h / 2 + self.lamp_y
        return cx, cy

    def jump(self, power=None):
        p = power if power is not None else self.jump_power
        if self.freeze_timer > 0: p = p / 1.3
        self.vy = p
        self.standing_platform = None
        self.standing_offset_x = 0.0

    def update_timers(self, dt):
        if self.freeze_timer > 0:
            self.freeze_timer = max(0, self.freeze_timer - dt)
        if self.ability_active:
            self.ability_timer -= dt
            if self.ability_timer <= 0:
                self.ability_active, self.cooldown = False, 15000
        elif self.cooldown > 0:
            self.cooldown = max(0, self.cooldown - dt)
        if self.spring_timer > 0:
            self.spring_timer -= dt
            if self.spring_timer <= 0:
                self.spring_timer = 0
                if self.spring_platform:
                    self.spring_platform.spring_anim = -1.0
                    self.spring_platform = None
                self.jump(-32)

    def activate_ability(self):
        if not self.ability_active and self.cooldown == 0:
            self.ability_active, self.ability_timer, self.jumps_left = True, 5000, 2

    def start_death(self, kind, impact_from=None):
        if kind not in ("electric", "spike", "fall"): kind = "electric"
        self.dying = True
        self.death_kind = kind
        self.standing_platform = None
        self.standing_offset_x = 0.0
        self.ability_active = False
        if kind == "spike":
            if impact_from is not None:
                px, py = impact_from
                cx = self.x + self.w / 2
                cy = self.y + self.h / 2
                dx = cx - px; dy = cy - py
                L = math.hypot(dx, dy) or 1.0
                nx, ny = dx / L, dy / L
                self.knockback_vx = nx * 6.0 + random.uniform(-1.5, 1.5)
                self.knockback_vy = -9.0 - random.uniform(0, 2)
                if ny < -0.3: self.knockback_vy -= 2.0
            else:
                self.knockback_vx = random.uniform(-5, 5)
                self.knockback_vy = -10.0
            self.death_timer = 1500
        elif kind == "fall":
            self.death_timer = 300
            self.knockback_vx = 0.0
            self.knockback_vy = 4.0
        else:
            self.death_timer = 900
            self.knockback_vx = 0.0
            self.knockback_vy = 0.0

    def update_death(self, dt):
        if self.death_kind == "spike":
            self.knockback_vy += 0.4 * dt / 16.0
            self.x += self.knockback_vx * dt / 16.0
            self.y += self.knockback_vy * dt / 16.0
            self.knockback_vx *= 0.995
            if self.x < -self.w * 2:
                self.x = -self.w * 2
                self.knockback_vx = abs(self.knockback_vx) * 0.5
            elif self.x > W + self.w:
                self.x = W + self.w
                self.knockback_vx = -abs(self.knockback_vx) * 0.5
        elif self.death_kind == "fall":
            self.knockback_vy += 0.8 * dt / 16.0
            self.y += self.knockback_vy * dt / 16.0

    def draw(self, surf):
        x, y, w, h = self.x, self.y, self.w, self.h
        pad = self._frog_pad
        if self.dying and self.death_kind == "spike":
            t = pygame.time.get_ticks()
            ang = (t * 0.35) % 360
            rotated = pygame.transform.rotate(self._frog_surface, ang)
            rect = rotated.get_rect(center=(x + w / 2, y + h / 2))
            surf.blit(rotated, rect.topleft)
        else:
            surf.blit(self._frog_surface, (int(x) - pad, int(y) - pad))
        if self.dying: return
        cx = x + w // 2; cy = y + h // 2
        t = pygame.time.get_ticks() * 0.005

        if self.has_lamp:
            lcx, lcy = self.get_lamp_pos()
            fuel_ratio = max(0.0, min(1.0, self.lamp_fuel_seconds / MINIGAME_DARK_FUEL_SECONDS))
            draw_oil_lamp(surf, lcx, lcy, self.lamp_offset, fuel=fuel_ratio)

        if self.ability_active:
            pulse = 1.0 + 0.12 * math.sin(t * 2)
            R = int(22 * pulse)
            aura = pygame.Surface((R * 2 + 6, R * 2 + 6), pygame.SRCALPHA)
            for i in range(1, 7):
                r = R * i / 6
                a = int(80 * (1 - i / 7))
                pygame.draw.circle(aura, (255, 210, 60, a), (R + 3, R + 3), int(r))
            surf.blit(aura, (cx - R - 3, cy - R - 3))
            for i in range(5):
                ang = t * 1.5 + i * (2 * math.pi / 5)
                sx = cx + math.cos(ang) * (R + 2)
                sy = cy + math.sin(ang) * (R + 2) * 0.7
                pygame.draw.circle(surf, (255, 240, 130), (int(sx), int(sy)), 2)
                pygame.draw.circle(surf, (255, 255, 220), (int(sx), int(sy)), 1)
        if self.freeze_timer > 0:
            intensity = min(1.0, self.freeze_timer / 1000.0)
            ice = pygame.Surface((w + 4, h + 4), pygame.SRCALPHA)
            for i in range(h + 4):
                a = int((200 - i * 4) * intensity)
                if a < 40: a = 40
                pygame.draw.line(ice, (190, 230, 255, a), (0, i), (w + 4, i))
            surf.blit(ice, (x - 2, y - 2))
            sh = 180 + int(60 * (0.5 + 0.5 * math.sin(t * 4)))
            pygame.draw.rect(surf, (sh, 235, 255), (x - 2, y - 2, w + 4, h + 4), 2, border_radius=8)
            for (ox, oy) in [(5, 5), (w - 5, 5), (5, h - 5), (w - 5, h - 5)]:
                draw_snowflake(surf, x + ox, y + oy, 4, (245, 250, 255))

    def draw_electric_death(self, surf):
        x, y, w, h = self.x, self.y, self.w, self.h
        cx = x + w // 2; cy = y + h // 2
        t = pygame.time.get_ticks()
        self.draw(surf)
        flicker_on = (t // 60) % 2 == 0
        flash_color = (230, 245, 255) if flicker_on else (120, 200, 255)
        flash = pygame.Surface((w + 4, h + 4), pygame.SRCALPHA)
        pygame.draw.ellipse(flash, (*flash_color, 150), (0, 0, w + 4, h + 4))
        surf.blit(flash, (x - 2, y - 2))
        rnd = random.Random(t // 50)
        for i in range(8):
            ang = (t * 0.02 + i * math.pi / 4) % (2 * math.pi)
            dist = w * 0.9
            sx = cx + math.cos(ang) * (dist * 0.4)
            sy = cy + math.sin(ang) * (dist * 0.4)
            ex = cx + math.cos(ang) * dist
            ey = cy + math.sin(ang) * dist
            mx = (sx + ex) / 2 + rnd.uniform(-5, 5)
            my = (sy + ey) / 2 + rnd.uniform(-5, 5)
            pts = [(sx, sy), (mx, my), (ex, ey)]
            pygame.draw.lines(surf, (150, 220, 255), False, pts, 3)
            pygame.draw.lines(surf, (255, 255, 255), False, pts, 1)
        for i in range(10):
            ang = rnd.uniform(0, 2 * math.pi)
            dist = rnd.uniform(w * 0.5, w * 1.0)
            sx = int(cx + math.cos(ang) * dist)
            sy = int(cy + math.sin(ang) * dist)
            if rnd.random() < 0.5:
                pygame.draw.circle(surf, (255, 240, 120), (sx, sy), 2)
            else:
                pygame.draw.circle(surf, (255, 255, 255), (sx, sy), 1)

    def draw_spike_hit(self, surf):
        x, y, w, h = self.x, self.y, self.w, self.h
        cx = x + w // 2; cy = y + h // 2
        self.draw(surf)
        if self.death_timer > 1000:
            t = pygame.time.get_ticks()
            rnd = random.Random(t // 40)
            for i in range(6):
                ang = rnd.uniform(0, 2 * math.pi)
                dist = rnd.uniform(6, 18)
                sx = int(cx + math.cos(ang) * dist)
                sy = int(cy + math.sin(ang) * dist)
                if rnd.random() < 0.5:
                    pygame.draw.circle(surf, (255, 90, 90), (sx, sy), 2)
                else:
                    pygame.draw.circle(surf, (255, 220, 120), (sx, sy), 1)


class Platform:
    RING_OFFSET = 10

    def __init__(self, x, y, p_type="normal", move_speed_mult=1.0):
        self.x, self.y, self.w, self.h = x, y, 70, 15
        self.type = p_type
        self.spring_w = 16
        if p_type == "spring":
            self.spring_x = random.randint(6, self.w - 6 - self.spring_w)
            self.spring_hit_pad = SPRING_HIT_PAD
        else:
            self.spring_x = 0
            self.spring_hit_pad = 0
        self.is_stepped = False; self.timer = 0; self.broken = False
        self.fall_offset = 0; self.fall_vy = 0; self.alpha = 255
        self.spring_anim = 0.0; self.electric_t = 0.0; self.last_regen = 0
        self.particles = []
        self._arc_local_pts = None
        self._arc_seed_cached = -1
        self._arc_surf = None
        self._arc_surf_size = (0, 0)
        self._arc_blit_offset = (0, 0)
        self._ground_surface = None
        self._ground_surface_w = -1
        self._danger_sign_surf = None
        self.vanish_fade = None
        self.fuel_taken = False
        if p_type == "danger": self._init_danger_caches()
        self._spike_body_surface = None
        self._spike_top_surface = None
        self._spike_bottom_surface = None
        if p_type == "spike": self._init_spike_caches()
        self.base_x = x; self.prev_x = x
        self.move_range = 0; self.move_phase = 0.0; self.move_speed = 0.0
        self.gear_angle = random.uniform(0, 2 * math.pi) if p_type == "moving" else 0.0
        if p_type == "moving":
            self.move_phase = random.uniform(0, 2 * math.pi)
            self.move_speed = BASE_MOVING_SPEED * move_speed_mult

    def spring_hit_rect(self):
        px1 = self.x + self.spring_x - self.spring_hit_pad
        px2 = self.x + self.spring_x + self.spring_w + self.spring_hit_pad
        return pygame.Rect(px1, self.y - 16, px2 - px1, self.h + 16)

    def _init_danger_caches(self):
        sign_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        cx = self.w // 2; cy = self.h // 2 + 1
        size = 6
        tri = [(cx, cy - size), (cx - size, cy + size - 2), (cx + size, cy + size - 2)]
        pygame.draw.polygon(sign_surf, (230, 240, 255, 90), tri)
        pygame.draw.polygon(sign_surf, (200, 230, 255, 200), tri, 1)
        pygame.draw.rect(sign_surf, (230, 240, 255, 200), (cx - 1, cy - 3, 2, 4))
        pygame.draw.rect(sign_surf, (230, 240, 255, 200), (cx - 1, cy + 2, 2, 1))
        self._danger_sign_surf = sign_surf

    def _make_spike_row(self, spike_h, flip):
        surf = pygame.Surface((self.w, spike_h), pygame.SRCALPHA)
        n_spikes = 6
        step = self.w / n_spikes
        for i in range(n_spikes):
            bx = i * step + step / 2
            half = step * 0.38
            if not flip:
                tip_y = 1; base_y = spike_h
                pts = [(bx - half, base_y), (bx, tip_y), (bx + half, base_y)]
                hilite_pts = ((bx, tip_y + 1), (bx - half * 0.4, base_y - 2))
                shadow_pts = ((bx, tip_y + 1), (bx + half * 0.4, base_y - 2))
            else:
                tip_y = spike_h - 1; base_y = 0
                pts = [(bx - half, base_y), (bx, tip_y), (bx + half, base_y)]
                hilite_pts = ((bx, tip_y - 1), (bx - half * 0.4, base_y + 2))
                shadow_pts = ((bx, tip_y - 1), (bx + half * 0.4, base_y + 2))
            pygame.draw.polygon(surf, (200, 200, 210), pts)
            pygame.draw.polygon(surf, (90, 90, 100), pts, 1)
            pygame.draw.line(surf, (245, 245, 255), hilite_pts[0], hilite_pts[1], 1)
            pygame.draw.line(surf, (60, 60, 70), shadow_pts[0], shadow_pts[1], 1)
        return surf

    def _init_spike_caches(self):
        body = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        pygame.draw.rect(body, STONE_MID, (0, 0, self.w, self.h), border_radius=3)
        pygame.draw.rect(body, STONE_DARK, (0, 0, self.w, self.h), 1, border_radius=3)
        pygame.draw.line(body, STONE_HILITE, (3, 2), (self.w - 3, 2), 1)
        for i in range(0, self.w, 14):
            pygame.draw.rect(body, STONE_DARK, (i + 4, 8, 4, 2))
            pygame.draw.rect(body, STONE_LIGHT, (i + 8, 12, 3, 1))
        self._spike_body_surface = body
        self._spike_top_surface = self._make_spike_row(SPIKE_H, flip=False)
        self._spike_bottom_surface = self._make_spike_row(SPIKE_H, flip=True)

    def _render_ground(self):
        s = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        pygame.draw.rect(s, (115, 75, 45), (0, 0, self.w, self.h), border_radius=4)
        pygame.draw.rect(s, (60, 195, 60), (0, 0, self.w, 7), border_radius=3)
        pygame.draw.line(s, (35, 130, 35), (2, 7), (self.w - 2, 7), 1)
        for i in range(0, self.w, 5):
            bx = i + 2
            gh = 2 + ((i // 5) % 3)
            pygame.draw.line(s, (90, 230, 90), (bx, 1), (bx, 1 - gh), 1)
        for i in range(0, self.w, 12):
            dx = i + 6
            dy = 10 + ((i // 12) % 2)
            pygame.draw.rect(s, (90, 55, 30), (dx, dy, 3, 2))
        self._ground_surface = s
        self._ground_surface_w = self.w

    def _draw_ground(self, surf):
        if self._ground_surface is None or self._ground_surface_w != self.w:
            self._render_ground()
        surf.blit(self._ground_surface, (self.x, self.y))

    def _gen_wrap_points_local(self, offset, seed):
        rnd = random.Random(seed)
        x1 = -offset; y1 = -offset
        x2 = self.w + offset; y2 = self.h + offset
        waypoints = [(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)]
        pts = []
        for i in range(len(waypoints) - 1):
            ax, ay = waypoints[i]
            bx, by = waypoints[i + 1]
            dx, dy = bx - ax, by - ay
            L = math.hypot(dx, dy)
            nx, ny = -dy / L, dx / L
            segs = 8
            for j in range(segs):
                t = j / segs
                px = ax + dx * t; py = ay + dy * t
                zig = math.sin(t * math.pi) * rnd.uniform(-4, 4) + rnd.uniform(-1.5, 1.5)
                pts.append((px + nx * zig, py + ny * zig))
        pts.append(waypoints[-1])
        return pts

    def _spawn_particles(self):
        for _ in range(6):
            px = self.x + random.uniform(4, self.w - 4)
            py = self.y + random.uniform(2, self.h - 2)
            vx = random.uniform(-1.2, 1.2)
            vy = random.uniform(-1.0, 0.5)
            r = random.uniform(5, 8)
            life = random.randint(500, 700)
            self.particles.append(Particle(px, py, vx, vy, r, life, gen=0))

    def update(self, dt):
        self.prev_x = self.x
        if self.type == "moving":
            self.move_phase += self.move_speed * dt / 1000.0
            frac = _triangle_frac(self.move_phase)
            self.x = self.base_x + (frac * 2 - 1) * self.move_range
            self.gear_angle += (self.x - self.prev_x) * 0.1
        if self.type == "break" and self.is_stepped and not self.broken:
            self.timer += dt
            if self.timer >= 300:
                self.broken = True
                self.fall_vy = 0
        if self.type == "break" and self.broken:
            self.fall_vy += 0.5
            self.fall_offset += self.fall_vy
            self.alpha = max(0, self.alpha - 8)
        if self.type == "cloud" and self.broken:
            for p in self.particles: p.update(dt)
            self.particles = [p for p in self.particles if p.life > 0 and p.r >= 0.5]
        if self.spring_anim > 0:
            self.spring_anim = max(0.0, self.spring_anim - dt / 150.0)
        elif self.spring_anim < 0:
            self.spring_anim = min(0.0, self.spring_anim + dt / 100.0)
        if self.type == "danger":
            self.electric_t += dt
            if self.electric_t - self.last_regen >= 70:
                self.last_regen = self.electric_t

    def draw(self, surf):
        if self.broken and self.type not in ("break", "cloud"):
            return
        fade = self.vanish_fade
        if fade is not None and self.type not in ("break", "cloud"):
            tmp = pygame.Surface((self.w + 40, self.h + 40), pygame.SRCALPHA)
            old_x, old_y = self.x, self.y
            self.x, self.y = 20, 20
            self._draw_single(tmp)
            self.x, self.y = old_x, old_y
            tmp.set_alpha(max(0, int(fade)))
            surf.blit(tmp, (int(old_x) - 20, int(old_y) - 20))
            return
        self._draw_single(surf)

    def _draw_single(self, surf):
        if self.type == "normal":
            self._draw_ground(surf)
        elif self.type == "fuel":
            self._draw_ground(surf)
            if not self.fuel_taken:
                draw_fuel_can(surf, self.x + self.w // 2,
                              self.y - 1)
        elif self.type == "spring":
            self._draw_ground(surf)
            sx = self.x + self.spring_x
            cx = sx + self.spring_w // 2
            base_h = 12
            coil_h = base_h * (1 - self.spring_anim * 0.4)
            coil_h = max(3, coil_h)
            top_y = self.y - coil_h
            for i in range(3):
                y = int(self.y - 2 - i * (coil_h / 2.0))
                pygame.draw.line(surf, (235, 235, 235), (cx - 6, y), (cx + 6, y), 2)
            pygame.draw.rect(surf, WHITE, (cx - 8, int(top_y) - 3, 16, 3), border_radius=2)
        elif self.type == "freeze":
            pygame.draw.rect(surf, (185, 225, 255), (self.x, self.y, self.w, self.h), border_radius=4)
            pygame.draw.rect(surf, (100, 180, 240), (self.x, self.y, self.w, self.h), 2, border_radius=4)
            cy = self.y + self.h // 2
            for sx in (self.x + 14, self.x + 35, self.x + 56):
                draw_snowflake(surf, sx, cy, 5, (250, 255, 255))
        elif self.type == "cloud":
            if self.broken:
                for p in self.particles: p.draw(surf)
                return
            pygame.draw.rect(surf, CLOUD, (self.x, self.y, self.w, self.h), border_radius=4)
            pygame.draw.rect(surf, (200, 215, 235), (self.x, self.y, self.w, self.h), 1, border_radius=4)
            side_puffs = [(self.x + 2,  self.y + 4, 6), (self.x + 1,  self.y + 10, 5),
                          (self.x - 2,  self.y + 8, 5), (self.x + self.w - 2, self.y + 4, 6),
                          (self.x + self.w - 1, self.y + 10, 5), (self.x + self.w + 2, self.y + 8, 5)]
            for (px, py, r) in side_puffs:
                pygame.draw.circle(surf, CLOUD, (int(px), int(py)), r)
                pygame.draw.circle(surf, (200, 215, 235), (int(px), int(py)), r, 1)
        elif self.type == "danger":
            pygame.draw.rect(surf, (80, 65, 150), (self.x, self.y, self.w, self.h), border_radius=4)
            pygame.draw.rect(surf, (140, 210, 255), (self.x, self.y, self.w, self.h), 2, border_radius=4)
            surf.blit(self._danger_sign_surf, (self.x, self.y))
            seed = int(self.electric_t / 70)
            if self._arc_seed_cached != seed or self._arc_local_pts is None:
                self._arc_seed_cached = seed
                self._arc_local_pts = self._gen_wrap_points_local(
                    self.RING_OFFSET, seed * 41 + int(self.x))
                xs = [p[0] for p in self._arc_local_pts]
                ys = [p[1] for p in self._arc_local_pts]
                min_x, max_x = min(xs), max(xs)
                min_y, max_y = min(ys), max(ys)
                pad = 4
                sw = int(max_x - min_x) + pad * 2
                sh = int(max_y - min_y) + pad * 2
                self._arc_blit_offset = (min_x - pad, min_y - pad)
                if self._arc_surf is None or self._arc_surf_size != (sw, sh):
                    self._arc_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
                    self._arc_surf_size = (sw, sh)
                self._arc_surf.fill((0, 0, 0, 0))
                local_pts = [(p[0] - min_x + pad, p[1] - min_y + pad)
                             for p in self._arc_local_pts]
                pygame.draw.lines(self._arc_surf, (150, 220, 255, 110), False, local_pts, 7)
                pygame.draw.lines(self._arc_surf, (220, 240, 255, 200), False, local_pts, 4)
                pygame.draw.lines(self._arc_surf, (255, 255, 255, 255), False, local_pts, 2)
            blit_x = self.x + self._arc_blit_offset[0]
            blit_y = self.y + self._arc_blit_offset[1]
            surf.blit(self._arc_surf, (blit_x, blit_y))
        elif self.type == "moving":
            fade = self.vanish_fade
            alpha = 255 if fade is None else max(0, int(fade))
            if alpha <= 0:
                return

            traj_x1 = int(self.base_x - self.move_range - 4)
            traj_x2 = int(self.base_x + self.move_range + self.w + 4)
            traj_y = int(self.y + self.h // 2)
            line_w = max(4, traj_x2 - traj_x1 + 4)
            line_surf = pygame.Surface((line_w, 12), pygame.SRCALPHA)
            lx1 = 2
            lx2 = line_w - 2
            ly = 6
            pygame.draw.line(line_surf, (*TRAJ_COLOR, alpha),
                             (lx1, ly), (lx2, ly), 1)
            pygame.draw.line(line_surf, (*TRAJ_COLOR, alpha),
                             (lx1, ly - 3), (lx1, ly + 3), 1)
            pygame.draw.line(line_surf, (*TRAJ_COLOR, alpha),
                             (lx2, ly - 3), (lx2, ly + 3), 1)
            surf.blit(line_surf, (traj_x1 - 2, traj_y - 6))

            frames = _get_gear_frames(5, 12)
            n = len(frames)
            idx_l = int(self.gear_angle * 3) % n
            idx_r = int(-self.gear_angle * 3) % n
            gs_l = frames[idx_l]; gs_r = frames[idx_r]
            gsz = gs_l.get_width(); goff = gsz // 2

            pad_top = 4
            pad_bottom = gsz + 4
            body_h = self.h + pad_top + pad_bottom
            body_w = self.w + gsz + 4
            body = pygame.Surface((body_w, body_h), pygame.SRCALPHA)

            bx = goff + 2
            by = pad_top

            pygame.draw.rect(body, STONE_MID, (bx, by, self.w, self.h),
                             border_radius=3)
            pygame.draw.rect(body, STONE_DARK, (bx, by, self.w, self.h), 1,
                             border_radius=3)
            pygame.draw.line(body, STONE_HILITE, (bx + 3, by + 2),
                             (bx + self.w - 3, by + 2), 1)
            for i in range(0, self.w, 14):
                pygame.draw.rect(body, STONE_DARK,
                                 (bx + i + 4, by + 6, 4, 2))
                pygame.draw.rect(body, STONE_LIGHT,
                                 (bx + i + 8, by + 11, 3, 1))

            body.blit(gs_l, (bx + 6 - goff, by + self.h + 5 - goff))
            body.blit(gs_r, (bx + self.w - 6 - goff, by + self.h + 5 - goff))

            body.set_alpha(alpha)
            surf.blit(body, (int(self.x) - bx, int(self.y) - by))
        elif self.type == "spike":
            surf.blit(self._spike_body_surface, (self.x, self.y))
            surf.blit(self._spike_top_surface, (self.x, self.y - (SPIKE_H - 1)))
            surf.blit(self._spike_bottom_surface, (self.x, self.y + self.h - 1))
        elif self.type == "break":
            if self.broken:
                if self.alpha <= 0: return
                piece_w = self.w // 2
                angle = min(self.fall_offset * 1.2, 75)
                left_surf = pygame.Surface((piece_w, self.h), pygame.SRCALPHA)
                pygame.draw.rect(left_surf, (*BROWN, self.alpha), (0, 0, piece_w, self.h), border_radius=2)
                rot_left = pygame.transform.rotate(left_surf, -angle)
                lc = (self.x + piece_w // 2, self.y + self.h // 2 + self.fall_offset)
                surf.blit(rot_left, rot_left.get_rect(center=lc))
                right_surf = pygame.Surface((piece_w, self.h), pygame.SRCALPHA)
                pygame.draw.rect(right_surf, (*BROWN, self.alpha), (0, 0, piece_w, self.h), border_radius=2)
                rot_right = pygame.transform.rotate(right_surf, angle)
                rc = (self.x + self.w - piece_w // 2, self.y + self.h // 2 + int(self.fall_offset * 0.9))
                surf.blit(rot_right, rot_right.get_rect(center=rc))
            else:
                pygame.draw.rect(surf, BROWN, (self.x, self.y, self.w, self.h), border_radius=2)
                pygame.draw.line(surf, (90, 45, 15), (self.x + 2, self.y), (self.x + self.w - 2, self.y), 1)
                pygame.draw.line(surf, (60, 30, 10), (self.x + 2, self.y + self.h - 1), (self.x + self.w - 2, self.y + self.h - 1), 1)
                for i in range(1, 4):
                    gy = self.y + i * (self.h // 4)
                    pygame.draw.line(surf, (105, 60, 30), (self.x + 3, gy), (self.x + self.w - 3, gy), 1)
                pygame.draw.line(surf, (160, 100, 55), (self.x + 4, self.y + 2), (self.x + self.w - 4, self.y + 2), 1)
                cx = self.x + self.w // 2
                crack_pts = [(cx, self.y + 1), (cx - 2, self.y + self.h // 3),
                             (cx + 2, self.y + 2 * self.h // 3), (cx, self.y + self.h - 1)]
                pygame.draw.lines(surf, (40, 20, 5), False, crack_pts, 1)


class FinishPlatform(Platform):
    def __init__(self, x, y):
        super().__init__(x, y, "finish")
        self.w = 90
        self.h = 20
        self._render_ground()

    def _render_ground(self):
        s = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        cell = 10
        cols = self.w // cell
        rows = self.h // cell + 1
        for r in range(rows):
            for c in range(cols):
                col = (255, 255, 255) if (r + c) % 2 == 0 else (25, 25, 30)
                pygame.draw.rect(s, col, (c * cell, r * cell, cell, cell))
        pygame.draw.rect(s, (40, 40, 40), (0, 0, self.w, self.h), 2, border_radius=2)
        self._ground_surface = s
        self._ground_surface_w = self.w

    def draw(self, surf):
        self._draw_ground(surf)
        cx = self.x + self.w // 2
        pole_top = self.y - 42
        pygame.draw.line(surf, (50, 50, 50), (cx, self.y), (cx, pole_top), 3)
        pygame.draw.circle(surf, (240, 240, 240), (cx, pole_top), 3)
        pygame.draw.circle(surf, (30, 30, 30), (cx, pole_top), 3, 1)
        flag_w = 30; flag_h = 20
        fx0 = cx + 1; fy0 = pole_top + 2
        pygame.draw.rect(surf, (220, 30, 40), (fx0, fy0, flag_w, flag_h))
        pygame.draw.rect(surf, (90, 20, 25), (fx0, fy0, flag_w, flag_h), 2)
        lbl = FONT.render("ФИНИШ", True, (20, 20, 20))
        surf.blit(lbl, lbl.get_rect(center=(self.x + self.w // 2, self.y + self.h + 14)))


def show_text(text, font, color, x, y, center=False):
    render = font.render(text, True, color)
    rect = render.get_rect(center=(x, y)) if center else render.get_rect(topleft=(x, y))
    screen.blit(render, rect)


async def how_to_play_screen():
    t = 0.0
    while True:
        dt = clock.tick(60)
        t += dt / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(t * 15)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        title = BIG_FONT.render("КАК ИГРАТЬ?", True, (30, 120, 40))
        screen.blit(title, title.get_rect(center=(W // 2, 35)))
        sec1 = BOLD_SMALL_FONT.render("УПРАВЛЕНИЕ", True, (180, 30, 30))
        screen.blit(sec1, (15, 75))
        controls = [
            "A / D  —  движение влево / вправо",
            "W  —  прыжок",
            "W в воздухе  —  второй прыжок (с K)",
            "K или R  —  способность «двойной прыжок»",
            "       (5 сек, перезарядка 15 сек)",
            "ESC  —  пауза",
            "ПРОБЕЛ  —  рестарт после проигрыша",
        ]
        y = 100
        for line in controls:
            lbl = SMALL_FONT.render(line, True, BLACK)
            screen.blit(lbl, (18, y)); y += 20
        sec2 = BOLD_SMALL_FONT.render("ПЛАТФОРМЫ", True, (180, 30, 30))
        screen.blit(sec2, (15, 250))
        plats = [
            ("Обычная", "безопасная, базовая", (115, 75, 45)),
            ("Пружина", "подкидывает высоко", (235, 235, 235)),
            ("Ломающаяся", "рушится через 0.3 сек", BROWN),
            ("Снежная", "замораживает на 1 сек", (185, 225, 255)),
            ("Облако", "исчезает после прыжка на нее", CLOUD),
            ("Двигающаяся", "ездит по горизонтали", STONE_MID),
            ("Электрическая", "убивает при касании", (80, 65, 150)),
            ("Шипы", "убивают сверху и снизу", (200, 200, 210)),
        ]
        y = 275
        for name, desc, col in plats:
            pygame.draw.rect(screen, col, (18, y + 2, 12, 12), border_radius=2)
            pygame.draw.rect(screen, BLACK, (18, y + 2, 12, 12), 1, border_radius=2)
            name_lbl = BOLD_SMALL_FONT.render(name, True, BLACK)
            screen.blit(name_lbl, (38, y))
            desc_lbl = SMALL_FONT.render("— " + desc, True, (60, 60, 60))
            screen.blit(desc_lbl, (38 + name_lbl.get_width() + 4, y + 1))
            y += 22
        sec3 = BOLD_SMALL_FONT.render("СОВЕТЫ", True, (180, 30, 30))
        screen.blit(sec3, (15, 470))
        tips = [
            "• Не наступай на шипы и электричество",
            "• Ломающаяся платформа рушится — прыгай сразу",
            "• После способности доступен двойной прыжок",
        ]
        y = 495
        for tip in tips:
            lbl = SMALL_FONT.render(tip, True, BLACK)
            screen.blit(lbl, (18, y)); y += 18
        hint = FONT.render("ESC — назад", True, (60, 60, 60))
        screen.blit(hint, hint.get_rect(center=(W // 2, H - 18)))
        pygame.display.flip()
        await asyncio.sleep(0)


async def levels_screen():
    title_font = pygame.font.SysFont("Arial", 34, bold=True)
    lvl_font = pygame.font.SysFont("Arial", 22, bold=True)
    page = 0
    total_pages = 2
    levels_per_page = 25
    levels_per_row = 5
    btn_size = 55
    gap_x = 12
    gap_y = 14
    grid_w = levels_per_row * btn_size + (levels_per_row - 1) * gap_x
    start_x = (W - grid_w) // 2
    start_y = 150
    arrow_size = 36
    arrow_margin = 6
    left_arrow = pygame.Rect(start_x - arrow_size - arrow_margin,
                             H // 2 - arrow_size // 2, arrow_size, arrow_size)
    right_arrow = pygame.Rect(start_x + grid_w + arrow_margin,
                              H // 2 - arrow_size // 2, arrow_size, arrow_size)
    level_buttons = []
    for i in range(levels_per_page):
        row = i // levels_per_row
        col = i % levels_per_row
        bx = start_x + col * (btn_size + gap_x) + btn_size // 2
        by = start_y + row * (btn_size + gap_y) + btn_size // 2
        level_buttons.append(Button(str(i + 1), bx, by, w=btn_size, h=btn_size,
                                    base_color=(70, 160, 90)))
    left_hover = 0.0; right_hover = 0.0
    left_pressed = False; right_pressed = False
    t = 0.0
    while True:
        dt = clock.tick(60)
        t += dt / 1000.0
        mouse_pos = pygame.mouse.get_pos()
        completed = load_progress()
        unlocked_up_to = min(WORKING_LEVELS, completed + 1)
        show_left = total_pages > 1 and page > 0
        show_right = total_pages > 1 and page < total_pages - 1
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return None
                if event.key == pygame.K_LEFT and page > 0:
                    page -= 1
                    for lb in level_buttons:
                        lb.hover_t = 0.0; lb.press_t = 0.0
                        lb.pressed = False; lb.hovered = False
                if event.key == pygame.K_RIGHT and page < total_pages - 1:
                    page += 1
                    for lb in level_buttons:
                        lb.hover_t = 0.0; lb.press_t = 0.0
                        lb.pressed = False; lb.hovered = False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if show_left and left_arrow.collidepoint(event.pos):
                    left_pressed = True
                if show_right and right_arrow.collidepoint(event.pos):
                    right_pressed = True
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if left_pressed and show_left and left_arrow.collidepoint(event.pos):
                    page -= 1
                    for lb in level_buttons:
                        lb.hover_t = 0.0; lb.press_t = 0.0
                        lb.pressed = False; lb.hovered = False
                if right_pressed and show_right and right_arrow.collidepoint(event.pos):
                    page += 1
                    for lb in level_buttons:
                        lb.hover_t = 0.0; lb.press_t = 0.0
                        lb.pressed = False; lb.hovered = False
                left_pressed = False; right_pressed = False
            for lb in level_buttons:
                lb.handle_event(event)
        for lb in level_buttons:
            lb.update(dt)
        for i, lb in enumerate(level_buttons):
            if lb.clicked:
                lb.clicked = False
                level_num = page * levels_per_page + i + 1
                if level_num <= WORKING_LEVELS and level_num <= unlocked_up_to:
                    return level_num
        left_target = 1.0 if (show_left and left_arrow.collidepoint(mouse_pos)) else 0.0
        right_target = 1.0 if (show_right and right_arrow.collidepoint(mouse_pos)) else 0.0
        left_hover += (left_target - left_hover) * min(1.0, dt / 80.0)
        right_hover += (right_target - right_hover) * min(1.0, dt / 80.0)
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(t * 15)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        title = title_font.render("УРОВНИ", True, (30, 120, 40))
        screen.blit(title, title.get_rect(center=(W // 2, 50)))
        for i, lb in enumerate(level_buttons):
            level_num = page * levels_per_page + i + 1
            lb.text = str(level_num)
            is_working = level_num <= WORKING_LEVELS
            is_unlocked = level_num <= unlocked_up_to
            is_completed = level_num <= completed
            if not is_working:
                lb.base_color = (120, 120, 130)
                lb.hover_color = (140, 140, 150)
                lb.press_color = (90, 90, 100)
            elif not is_unlocked:
                lb.base_color = (140, 140, 140)
                lb.hover_color = (150, 150, 150)
                lb.press_color = (110, 110, 110)
            elif is_completed:
                lb.base_color = (60, 180, 100)
                lb.hover_color = (90, 210, 130)
                lb.press_color = (40, 140, 70)
            else:
                lb.base_color = (90, 130, 200)
                lb.hover_color = (120, 160, 230)
                lb.press_color = (60, 100, 160)
            lb.draw(screen, lvl_font)
            if is_completed and is_working:
                draw_star_icon(screen, lb.rect.right - 10, lb.rect.top + 10,
                               r=7, fill=(255, 220, 70), outline=(140, 90, 10))
        def lerp3(a, b, tt):
            return tuple(int(a[i] + (b[i] - a[i]) * tt) for i in range(3))
        def draw_arrow(rect, direction, hover, pressed):
            base_c = (150, 150, 150); hover_c = (190, 190, 190)
            press_c = (110, 110, 110); border_c = (90, 90, 90)
            col = lerp3(base_c, hover_c, hover)
            col = lerp3(col, press_c, 1.0 if pressed else 0.0)
            cx, cy = rect.center
            size = 11
            if direction == "left":
                pts = [(cx + size // 2, cy - size), (cx - size // 2, cy),
                       (cx + size // 2, cy + size)]
            else:
                pts = [(cx - size // 2, cy - size), (cx + size // 2, cy),
                       (cx - size // 2, cy + size)]
            pygame.draw.polygon(screen, col, pts)
            pygame.draw.polygon(screen, border_c, pts, 2)
        if show_left: draw_arrow(left_arrow, "left", left_hover, left_pressed)
        if show_right: draw_arrow(right_arrow, "right", right_hover, right_pressed)
        hint = FONT.render("ESC — назад", True, (80, 80, 80))
        screen.blit(hint, hint.get_rect(center=(W // 2, H - 20)))
        pygame.display.flip()
        await asyncio.sleep(0)


async def level_complete_screen(level_num):
    has_next = level_num < WORKING_LEVELS
    while True:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "menu"
                if event.key == pygame.K_SPACE:
                    return "next" if has_next else "menu"
                if event.key == pygame.K_q:
                    return "levels"
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(pygame.time.get_ticks() * 0.015)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        draw_star_icon(screen, W // 2, H // 2 - 130, r=36,
                       fill=(255, 215, 80), outline=(200, 150, 20))
        show_text("УРОВЕНЬ ПРОЙДЕН!", BIG_FONT, (30, 160, 50),
                  W // 2, H // 2 - 60, center=True)
        if has_next:
            show_text("ПРОБЕЛ — следующий уровень", FONT, GREEN,
                      W // 2, H // 2 + 20, center=True)
        else:
            show_text("Все уровни пройдены!", FONT, GREEN,
                      W // 2, H // 2 + 20, center=True)
            show_text("ПРОБЕЛ — в меню", FONT, GREEN,
                      W // 2, H // 2 + 50, center=True)
        draw_outlined_text(screen, "ESC — в меню", FONT,
                           (180, 180, 180), (20, 20, 20),
                           W // 2 - 75, H // 2 + 100)
        draw_outlined_text(screen, "Q — к уровням", FONT,
                           (180, 180, 180), (20, 20, 20),
                           W // 2 + 75, H // 2 + 100)
        pygame.display.flip()
        await asyncio.sleep(0)


async def level_fail_screen(level_num, score):
    while True:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return "retry"
                if event.key == pygame.K_ESCAPE:
                    return "menu"
                if event.key == pygame.K_q:
                    return "levels"
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(pygame.time.get_ticks() * 0.015)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        draw_broken_flag(screen, W // 2, 130, scale=1.2)
        show_text("ИГРА ОКОНЧЕНА", BIG_FONT, BLACK, W // 2, H // 2 - 60, center=True)
        show_text(f"Уровень {level_num}", FONT, BLACK, W // 2, H // 2 - 10, center=True)
        show_text(f"Высота: {score} м", FONT, BLACK, W // 2, H // 2 + 20, center=True)
        show_text("ПРОБЕЛ — начать заново", FONT, GREEN,
                  W // 2, H // 2 + 70, center=True)
        draw_outlined_text(screen, "ESC — в меню", FONT,
                           (180, 180, 180), (20, 20, 20),
                           W // 2 - 75, H // 2 + 120)
        draw_outlined_text(screen, "Q — к уровням", FONT,
                           (180, 180, 180), (20, 20, 20),
                           W // 2 + 75, H // 2 + 120)
        pygame.display.flip()
        await asyncio.sleep(0)


async def victory_animation(level_num, platforms, bg_clouds, frog, score):
    has_next = level_num < WORKING_LEVELS
    confetti_list = []

    finish_p = None
    for p in platforms:
        if p.type == "finish":
            finish_p = p
            break
    if finish_p is not None:
        cx = finish_p.x + finish_p.w // 2
        cy = finish_p.y + finish_p.h // 2
    else:
        cx = frog.x + frog.w // 2
        cy = frog.y + frog.h // 2

    spawn_confetti_burst(confetti_list, cx, cy, count=110)

    text_delay = 500
    elapsed = 0

    while True:
        dt = clock.tick(60)
        elapsed += dt

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if elapsed >= text_delay:
                    if event.key == pygame.K_ESCAPE:
                        return "menu"
                    if event.key == pygame.K_SPACE:
                        return "next" if has_next else "menu"
                    if event.key == pygame.K_q:
                        return "levels"

        screen.fill(BG)
        draw_sun(screen)
        for c in bg_clouds:
            c.draw(screen)
        for p in platforms:
            p.draw(screen)
        frog.draw(screen)
        show_text(f"Высота: {score} м", FONT, BLACK, 10, 10)

        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 25))
        screen.blit(ov, (0, 0))

        update_and_draw_confetti(confetti_list, dt, screen)

        if elapsed < text_delay:
            t = elapsed / text_delay
            radius = int(30 + t * 180)
            alpha = int(160 * (1 - t))
            if alpha > 0:
                flash = pygame.Surface((W, H), pygame.SRCALPHA)
                pygame.draw.circle(flash, (255, 240, 180, alpha),
                                   (cx, cy), radius)
                screen.blit(flash, (0, 0))

        if elapsed >= text_delay:
            draw_star_icon(screen, W // 2, H // 2 - 100, r=34,
                           fill=(255, 215, 80), outline=(200, 150, 20))
            show_text("УРОВЕНЬ ПРОЙДЕН!", BIG_FONT, (30, 160, 50),
                      W // 2, H // 2 - 35, center=True)
            if has_next:
                show_text("ПРОБЕЛ — следующий уровень", FONT, GREEN,
                          W // 2, H // 2 + 40, center=True)
            else:
                show_text("Все уровни пройдены!", FONT, GREEN,
                          W // 2, H // 2 + 40, center=True)
                show_text("ПРОБЕЛ — в меню", FONT, GREEN,
                          W // 2, H // 2 + 70, center=True)
            draw_outlined_text(screen, "ESC — в меню", FONT,
                               (180, 180, 180), (20, 20, 20),
                               W // 2 - 75, H // 2 + 120)
            draw_outlined_text(screen, "Q — к уровням", FONT,
                               (180, 180, 180), (20, 20, 20),
                               W // 2 + 75, H // 2 + 120)

        pygame.display.flip()
        await asyncio.sleep(0)


async def run_level(level_num):
    level_config = {
        1:  {"target": 500,  "gap_mult": 1.0,  "break_chance": 0.0,   "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0},
        2:  {"target": 750,  "gap_mult": 1.15, "break_chance": 0.0,   "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0},
        3:  {"target": 1000, "gap_mult": 1.30, "break_chance": 0.0,   "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0},
        4:  {"target": 1000, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0,  "tutorial_break": True},
        5:  {"target": 1500, "gap_mult": 1.0,  "break_chance": 0.275, "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0},
        6:  {"target": 500,  "gap_mult": 1.0,  "break_chance": 1.0,   "cloud_chance": 0.0,  "spring_chance": 0.0,  "danger_bonus": 0.0},
        7:  {"target": 1500, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.0,  "danger_bonus": 0.0,  "tutorial_cloud": True},
        8:  {"target": 2000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.25, "spring_chance": 0.0,  "danger_bonus": 0.0},
        9:  {"target": 2500, "gap_mult": 1.25, "break_chance": 0.175, "cloud_chance": 0.45, "spring_chance": 0.0,  "danger_bonus": 0.0},
        10: {"target": 3000, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.25, "danger_bonus": 0.0,  "tutorial_spring": True},
        11: {"target": 3500, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07, "danger_bonus": 0.0},
        12: {"target": 4000, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07, "danger_bonus": 0.0},
        13: {"target": 4000, "gap_mult": 1.0,  "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07, "danger_bonus": 0.0,
             "tutorial_freeze": True},
        14: {"target": 4500, "gap_mult": 1.05, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "freeze_chance": 0.28, "danger_bonus": 0.0},
        15: {"target": 5000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "freeze_replace_chance": 0.10,  "danger_bonus": 0.0},
        16: {"target": 5000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "tutorial_danger": True, "danger_bonus": 0.03},
        17: {"target": 6000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "danger_bonus": 0.08},
        18: {"target": 7000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "danger_bonus": 0.13},
        19: {"target": 7000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "tutorial_moving": True},
        20: {"target": 8000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07},
        21: {"target": 9000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07},
        22: {"target": 10000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "tutorial_spike": True, "spike_bonus": 0.03},
        23: {"target": 11000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "spike_bonus": 0.08},
        24: {"target": 12000, "gap_mult": 1.10, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "spike_bonus": 0.13},
        25: {"target": 20000, "gap_mult": 1.0, "break_chance": 0.175, "cloud_chance": 0.10, "spring_chance": 0.07,
             "infinite_mode": True},
    }
    cfg = level_config.get(level_num, level_config[1])
    target_score = cfg["target"]
    gap_mult = cfg["gap_mult"]
    break_chance = cfg.get("break_chance", 0.0)
    cloud_chance = cfg.get("cloud_chance", 0.0)
    spring_chance = cfg.get("spring_chance", 0.0)
    is_tutorial_break = cfg.get("tutorial_break", False)
    is_tutorial_cloud = cfg.get("tutorial_cloud", False)
    is_tutorial_spring = cfg.get("tutorial_spring", False)
    is_tutorial_freeze = cfg.get("tutorial_freeze", False)
    is_tutorial_danger = cfg.get("tutorial_danger", False)
    is_tutorial_moving = cfg.get("tutorial_moving", False)
    is_tutorial_spike = cfg.get("tutorial_spike", False)
    freeze_chance = cfg.get("freeze_chance", 0.0)
    level_freeze_replace_chance = cfg.get("freeze_replace_chance", 0.0)
    danger_bonus = cfg.get("danger_bonus", 0.0)
    spike_bonus = cfg.get("spike_bonus", 0.0)
    infinite_mode = cfg.get("infinite_mode", False)

    if level_num >= LEVEL_INTRO_FREEZE and "freeze_chance" not in cfg:
        freeze_chance = INFINITE_FREEZE_CHANCE
    if level_num >= LEVEL_INTRO_FREEZE_REPLACE and "freeze_replace_chance" not in cfg:
        level_freeze_replace_chance = FREEZE_REPLACE_CHANCE
    spike_active = (level_num >= LEVEL_INTRO_SPIKE)
    moving_active = (level_num >= LEVEL_INTRO_MOVING)
    danger_active = (level_num >= LEVEL_INTRO_DANGER)

    def level_danger_chance(score_val):
        if not danger_active:
            return 0.0
        if infinite_mode:
            return danger_chance(score_val)
        return danger_bonus if danger_bonus > 0 else FLAT_DANGER_CHANCE

    def level_spike_chance(score_val):
        if not spike_active:
            return 0.0
        if infinite_mode:
            return spike_chance(score_val)
        return spike_bonus if spike_bonus > 0 else FLAT_SPIKE_CHANCE

    frog = Frog()
    score = 0

    start_w = 200 if level_num in (16, 22) else 100
    platforms = [Platform(W // 2 - start_w // 2, H - 100, "normal")]
    platforms[0].w = start_w
    platforms[0]._ground_surface = None
    platforms[0]._ground_surface_w = -1

    tutorial_break_platform = None
    tutorial_cloud_platform = None
    tutorial_spring_platform = None
    tutorial_freeze_platform = None
    tutorial_danger_platform = None
    tutorial_moving_platform = None
    tutorial_spike_platform = None

    next_gap_reduced = False
    next_must_be_normal = False

    def random_type():
        nonlocal next_gap_reduced
        if level_num == 6:
            return "break", False
        if infinite_mode:
            if random.random() < freeze_replace_chance(score):
                return "freeze", True
            if (score >= MOVING_START_SCORE
                    and random.random() < MOVING_REPLACE_CHANCE):
                return "moving", False
            r = random.random()
            if r < cloud_chance:
                return "cloud", False
            elif r < cloud_chance + break_chance:
                return "break", False
            elif r < cloud_chance + break_chance + spring_chance:
                return "spring", False
            return "normal", False
        else:
            if level_freeze_replace_chance > 0 and random.random() < level_freeze_replace_chance:
                return "freeze", True
            if moving_active and random.random() < MOVING_REPLACE_CHANCE:
                return "moving", False
            r = random.random()
            if r < cloud_chance:
                return "cloud", False
            elif r < cloud_chance + break_chance:
                return "break", False
            elif r < cloud_chance + break_chance + spring_chance:
                return "spring", False
            return "normal", False

    def add_with_cloud_support(x, y, p_type):
        if p_type == "moving":
            plat_w = 70
            need = MOVING_RANGE_MAX
            available = W - plat_w
            if available < 2 * need:
                platforms.append(Platform(x, y, "normal"))
            else:
                moving_base = random.randint(need, available - need)
                moving_mr = random.randint(MOVING_RANGE_MIN, MOVING_RANGE_MAX)
                new_plat = Platform(x, y, "moving",
                                    move_speed_mult=moving_speed_mult(score))
                new_plat.base_x = moving_base
                new_plat.move_range = moving_mr
                new_plat.move_phase = random.choice([
                    math.pi * 0.3, math.pi * 0.7,
                    math.pi * 1.3, math.pi * 1.7,
                ])
                frac = _triangle_frac(new_plat.move_phase)
                new_plat.x = new_plat.base_x + (frac * 2 - 1) * new_plat.move_range
                new_plat.prev_x = new_plat.x
                platforms.append(new_plat)
        else:
            platforms.append(Platform(x, y, p_type))

        if p_type == "cloud":
            sup_x = x + 90
            if sup_x + 70 > W:
                sup_x = x - 90
            if sup_x < 0:
                sup_x = 0
            platforms.append(Platform(sup_x, y, "normal"))

    if is_tutorial_break:
        tutorial_break_platform = Platform(W // 2 - 35, H - 230, "break")
        platforms.append(tutorial_break_platform)
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type = "break" if random.random() < break_chance else "normal"
            platforms.append(Platform(x, y, p_type))
    elif is_tutorial_cloud:
        cloud_x = W // 2 - 35
        cloud_y = H - 230
        tutorial_cloud_platform = Platform(cloud_x, cloud_y, "cloud")
        platforms.append(tutorial_cloud_platform)
        gap = 20
        danger_left = cloud_x - gap - 70
        danger_right = cloud_x + 70 + gap
        options = []
        if danger_left >= 0: options.append(danger_left)
        if danger_right + 70 <= W: options.append(danger_right)
        support_x = random.choice(options) if options else max(0, min(W - 70, cloud_x + 90))
        platforms.append(Platform(support_x, cloud_y, "normal"))
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    elif is_tutorial_spring:
        spring_x = W // 2 - 35
        spring_y = H - 230
        tutorial_spring_platform = Platform(spring_x, spring_y, "spring")
        tutorial_spring_platform.spring_x = (tutorial_spring_platform.w
                                             - tutorial_spring_platform.spring_w) // 2
        platforms.append(tutorial_spring_platform)
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    elif is_tutorial_freeze:
        freeze_x = W // 2 - 35
        freeze_y = H - 230
        tutorial_freeze_platform = Platform(freeze_x, freeze_y, "freeze")
        platforms.append(tutorial_freeze_platform)
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    elif is_tutorial_danger:
        danger_x = W // 2 - 35
        danger_y = H - 230
        tutorial_danger_platform = Platform(danger_x, danger_y, "danger")
        platforms.append(tutorial_danger_platform)
        gap = 20
        danger_left = danger_x - gap - 70
        danger_right = danger_x + 70 + gap
        options = []
        if danger_left >= 0: options.append(danger_left)
        if danger_right + 70 <= W: options.append(danger_right)
        safe_x = random.choice(options) if options else max(0, min(W - 70, danger_x + 90))
        platforms.append(Platform(safe_x, danger_y, "normal"))
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    elif is_tutorial_moving:
        moving_w = 70
        moving_base = (W - moving_w) // 2
        moving_range = moving_base
        tutorial_moving_platform = Platform(moving_base, H - 230, "moving",
                                            move_speed_mult=1.0)
        tutorial_moving_platform.base_x = moving_base
        tutorial_moving_platform.move_range = moving_range
        tutorial_moving_platform.move_phase = 0.0
        tutorial_moving_platform.move_speed = BASE_MOVING_SPEED * 1.0
        frac = _triangle_frac(tutorial_moving_platform.move_phase)
        tutorial_moving_platform.x = moving_base + (frac * 2 - 1) * moving_range
        tutorial_moving_platform.prev_x = tutorial_moving_platform.x
        platforms.append(tutorial_moving_platform)
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    elif is_tutorial_spike:
        spike_x = W // 2 - 35
        spike_y = H - 230
        tutorial_spike_platform = Platform(spike_x, spike_y, "spike")
        platforms.append(tutorial_spike_platform)
        gap = 20
        spike_left = spike_x - gap - 70
        spike_right = spike_x + 70 + gap
        options = []
        if spike_left >= 0: options.append(spike_left)
        if spike_right + 70 <= W: options.append(spike_right)
        safe_x = random.choice(options) if options else max(0, min(W - 70, spike_x + 90))
        platforms.append(Platform(safe_x, spike_y, "normal"))
        for i in range(7):
            y = H - 310 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)
    else:
        for i in range(8):
            y = H - 180 - (i * 70)
            x = random.randint(0, W - 70)
            p_type, _ = random_type()
            add_with_cloud_support(x, y, p_type)

    total_rise = 0.0
    start_world_y = H - 130
    respawns_left = MAX_RESPAWNS
    last_safe_y = None

    finish_world_y = start_world_y - target_score / 0.4 + frog.h + 25
    fx = random.randint(20, W - 110)
    finish_plat = FinishPlatform(fx, int(finish_world_y))
    platforms.append(finish_plat)

    bg_clouds = []
    for _ in range(6):
        bg_clouds.append(BackgroundCloud(bg_clouds))
    paused = False
    spring_launched = False
    last_safe_platform = None

    pause_btn_restart = Button("Перезагрузить", W // 2, H // 2 - 10,
                               w=240, h=50, base_color=(70, 170, 90))
    pause_btn_levels = Button("Выйти к уровням", W // 2, H // 2 + 55,
                              w=240, h=50, base_color=(90, 130, 200))
    pause_btn_menu = Button("Выйти в меню", W // 2, H // 2 + 120,
                            w=240, h=50, base_color=(200, 80, 100))

    def compute_score(frog_y, rise):
        world_y = frog_y - rise
        return max(0, int((start_world_y - world_y) * 0.4))

    def spawn_level_platform(existing_top):
        nonlocal next_gap_reduced, next_must_be_normal

        if infinite_mode:
            min_gap, max_gap = platform_gap_range(score)
        else:
            min_gap = int(65 * gap_mult)
            max_gap = int(85 * gap_mult)

        if next_gap_reduced:
            min_gap = int(min_gap * 0.45)
            max_gap = int(max_gap * 0.55)
            max_gap = min(max_gap, 50)
            min_gap = min(min_gap, max_gap - 5)
            next_gap_reduced = False

        pad_x = 40
        pad_y = 40

        fin_rect = pygame.Rect(
            finish_plat.x - pad_x,
            finish_plat.y - pad_y,
            finish_plat.w + 2 * pad_x,
            finish_plat.h + 2 * pad_y,
        )

        for _ in range(30):
            y = existing_top - random.randint(min_gap, max_gap)
            if y <= finish_plat.y + pad_y:
                return existing_top
            x = random.randint(0, W - 70)
            new_rect = pygame.Rect(x, y, 70, 15)
            if new_rect.colliderect(fin_rect):
                left_max = fin_rect.left - 70
                right_min = fin_rect.right
                options = []
                if left_max >= 0: options.append((0, left_max))
                if right_min <= W - 70: options.append((right_min, W - 70))
                if not options: return existing_top
                x_min, x_max = random.choice(options)
                x = random.randint(x_min, x_max)

            if next_must_be_normal:
                p_type = "normal"
                was_replace = False
                next_must_be_normal = False
            else:
                p_type, was_replace = random_type()

            moving_mr = None
            moving_base = None
            if p_type == "moving":
                plat_w = 70
                need = MOVING_RANGE_MAX
                available = W - plat_w
                if available < 2 * need:
                    p_type = "normal"
                else:
                    moving_base = random.randint(need, available - need)
                    moving_mr = random.randint(MOVING_RANGE_MIN, MOVING_RANGE_MAX)

            new_plat = Platform(x, y, p_type, move_speed_mult=moving_speed_mult(score))
            if p_type == "moving":
                new_plat.base_x = moving_base
                new_plat.move_range = moving_mr
                new_plat.move_phase = random.choice([
                    math.pi * 0.3, math.pi * 0.7,
                    math.pi * 1.3, math.pi * 1.7,
                ])
                frac = _triangle_frac(new_plat.move_phase)
                new_plat.x = new_plat.base_x + (frac * 2 - 1) * new_plat.move_range
                new_plat.prev_x = new_plat.x
            platforms.append(new_plat)

            if was_replace:
                next_gap_reduced = True
                next_must_be_normal = True

            if p_type == "cloud":
                sup_x = x + 90
                if sup_x + 70 > W: sup_x = x - 90
                if sup_x < 0: sup_x = 0
                sup_rect = pygame.Rect(sup_x, y, 70, 15)
                if not sup_rect.colliderect(fin_rect):
                    platforms.append(Platform(sup_x, y, "normal"))
                else:
                    alt_x = x - 90
                    if alt_x < 0: alt_x = 0
                    alt_rect = pygame.Rect(alt_x, y, 70, 15)
                    if not alt_rect.colliderect(fin_rect):
                        platforms.append(Platform(alt_x, y, "normal"))

            if infinite_mode:
                do_freeze_extra = score >= 2000 and random.random() < 0.18
            else:
                do_freeze_extra = freeze_chance > 0 and random.random() < freeze_chance

            if do_freeze_extra:
                spec_y = y - random.randint(35, 50)
                if spec_y > finish_plat.y + pad_y:
                    sx = None
                    for _try in range(20):
                        cand_x = random.randint(0, W - 70)
                        cand_rect = pygame.Rect(cand_x, spec_y, 70, 15)
                        if cand_rect.colliderect(fin_rect): continue
                        overlap = False
                        for p in platforms:
                            if p.broken: continue
                            if not _overlaps_vertical(p, spec_y, 15, margin=4): continue
                            if cand_rect.colliderect(pygame.Rect(p.x, p.y, p.w, p.h)):
                                overlap = True; break
                        if not overlap: sx = cand_x; break
                    if sx is None: sx = random.randint(0, W - 70)
                    platforms.append(Platform(sx, spec_y, "freeze"))

            d_chance = level_danger_chance(score)
            if d_chance > 0 and count_type(platforms, "danger") < MAX_DANGER_PLATFORMS:
                if random.random() < d_chance:
                    spec_y_d = y - random.randint(35, 50)
                    if spec_y_d > finish_plat.y + pad_y:
                        dx = None
                        for _try in range(20):
                            cand_x = random.randint(0, W - 70)
                            cand_rect = pygame.Rect(cand_x, spec_y_d, 70, 15)
                            if cand_rect.colliderect(fin_rect): continue
                            overlap = False
                            for p in platforms:
                                if p.broken: continue
                                if not _overlaps_vertical(p, spec_y_d, 15, margin=DANGER_SAFE_GAP): continue
                                if cand_rect.colliderect(pygame.Rect(p.x, p.y, p.w, p.h)):
                                    overlap = True; break
                            if not overlap and is_danger_safe(cand_x, spec_y_d, platforms):
                                dx = cand_x; break
                        if dx is not None:
                            platforms.append(Platform(dx, spec_y_d, "danger"))

            if spike_active:
                s_chance = level_spike_chance(score)
                if s_chance > 0 and count_type(platforms, "spike") < MAX_DANGER_PLATFORMS:
                    if random.random() < s_chance:
                        spec_y_s = y - random.randint(35, 50)
                        if spec_y_s > finish_plat.y + pad_y:
                            spx = None
                            for _try in range(20):
                                cand_x = random.randint(0, W - 70)
                                cand_rect = pygame.Rect(cand_x, spec_y_s, 70, 15)
                                if cand_rect.colliderect(fin_rect): continue
                                overlap = False
                                for p in platforms:
                                    if p.broken: continue
                                    if not _overlaps_vertical(p, spec_y_s, 15, margin=DANGER_SAFE_GAP): continue
                                    if cand_rect.colliderect(pygame.Rect(p.x, p.y, p.w, p.h)):
                                        overlap = True; break
                                if not overlap and is_danger_safe(cand_x, spec_y_s, platforms):
                                    spx = cand_x; break
                            if spx is not None:
                                platforms.append(Platform(spx, spec_y_s, "spike"))
            return y

        return existing_top

    while True:
        dt = clock.tick(60)
        events = pygame.event.get()

        if paused:
            unpause = False
            for event in events:
                if event.type == pygame.QUIT:
                    save_high_score(high_score); pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    unpause = True
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    pygame.event.clear()
                    return "retry"
                else:
                    pause_btn_menu.handle_event(event)
                    pause_btn_levels.handle_event(event)
                    pause_btn_restart.handle_event(event)
            if unpause:
                paused = False
                pause_btn_menu.reset_state()
                pause_btn_levels.reset_state()
                pause_btn_restart.reset_state()
                pygame.event.clear()
                continue
            pause_btn_menu.update(dt)
            pause_btn_levels.update(dt)
            pause_btn_restart.update(dt)
            screen.fill(BG)
            draw_sun(screen)
            for c in bg_clouds: c.draw(screen)
            for p in platforms: p.draw(screen)
            frog.draw(screen)
            show_text(f"Высота: {score} / {target_score} м", FONT, BLACK, 10, 10)
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            screen.blit(ov, (0, 0))
            show_text(f"Уровень {level_num}", FONT, (255, 220, 120),
                      W // 2, H // 2 - 165, center=True)
            show_text("ПАУЗА", BIG_FONT, WHITE, W // 2, H // 2 - 120, center=True)
            show_text("ESC — продолжить", FONT, WHITE, W // 2, H // 2 - 75, center=True)
            pause_btn_restart.draw(screen, FONT)
            pause_btn_levels.draw(screen, FONT)
            pause_btn_menu.draw(screen, FONT)
            pygame.display.flip()
            await asyncio.sleep(0)
            if pause_btn_menu.clicked:
                pause_btn_menu.reset_state(); pause_btn_levels.reset_state(); pause_btn_restart.reset_state()
                pygame.event.clear()
                return "menu"
            if pause_btn_levels.clicked:
                pause_btn_menu.reset_state(); pause_btn_levels.reset_state(); pause_btn_restart.reset_state()
                pygame.event.clear()
                return "levels"
            if pause_btn_restart.clicked:
                pause_btn_menu.reset_state(); pause_btn_levels.reset_state(); pause_btn_restart.reset_state()
                pygame.event.clear()
                return "retry"
            continue

        for event in events:
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: paused = True
                elif event.key in [pygame.K_r, pygame.K_k]:
                    frog.activate_ability()

        if frog.dying:
            frog.update_death(dt); frog.death_timer -= dt
            for c in bg_clouds: c.update(0, bg_clouds)
            screen.fill(BG)
            draw_sun(screen)
            for c in bg_clouds: c.draw(screen)
            for p in platforms: p.draw(screen)
            if frog.death_kind == "spike":
                frog.draw_spike_hit(screen)
            elif frog.death_kind == "electric":
                frog.draw_electric_death(screen)
            else:
                frog.draw(screen)
            show_text(f"Высота: {score} / {target_score} м", FONT, BLACK, 10, 10)
            pygame.display.flip()
            await asyncio.sleep(0)
            if frog.death_timer <= 0:
                if respawns_left > 0:
                    respawn_result = await respawn_screen(score, respawns_left, show_high_score=False)
                else:
                    respawn_result = "skip"
                if respawn_result == "respawn":
                    respawns_left -= 1
                    frog = Frog()
                    target_plat = choose_respawn_target(platforms, last_safe_platform, last_safe_y)
                    if target_plat is not None:
                        frog.x = target_plat.x + target_plat.w // 2 - frog.w // 2
                        frog.y = target_plat.y - frog.h - 2
                        frog.vy = 0
                        frog.standing_platform = target_plat
                        frog.standing_offset_x = frog.x - target_plat.x
                    spring_launched = False
                    continue
                else:
                    result = await level_fail_screen(level_num, score)
                    pygame.event.clear()
                    if result == "retry": return "retry"
                    elif result == "levels": return "levels"
                    else: return "menu"
            continue

        frog.update_timers(dt)
        for p in platforms: p.update(dt)

        on_moving = False
        if frog.standing_platform is not None:
            sp = frog.standing_platform
            if sp not in platforms or sp.broken:
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
            elif sp.type == "moving":
                on_moving = True

        if on_moving:
            sp = frog.standing_platform
            keys = pygame.key.get_pressed()
            speed = 5
            if frog.freeze_timer > 0: speed = 5 / 1.3
            if keys[pygame.K_a]: frog.standing_offset_x -= speed
            if keys[pygame.K_d]: frog.standing_offset_x += speed
            min_off = -frog.w + 4
            max_off = sp.w - 4
            if frog.standing_offset_x < min_off or frog.standing_offset_x > max_off:
                frog.x = sp.x + frog.standing_offset_x
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
                on_moving = False
                frog.move()
            else:
                frog.x = sp.x + frog.standing_offset_x
                frog.y = sp.y - frog.h
                frog.vy = 0
                if keys[pygame.K_w]:
                    frog.jump()
                    on_moving = False
        else:
            frog.move()

        w_down = pygame.key.get_pressed()[pygame.K_w]
        on_plat = False
        is_dead = False; death_kind = None; death_from = None
        f_rect = pygame.Rect(frog.x, frog.y, frog.w, frog.h)

        if not spring_launched:
            for p in platforms:
                if p.broken: continue
                if p.type == "danger":
                    R = p.RING_OFFSET
                    outer = pygame.Rect(p.x - R, p.y - R, p.w + 2 * R, p.h + 2 * R)
                    if f_rect.colliderect(outer):
                        is_dead = True; death_kind = "electric"; break
                elif p.type == "spike":
                    spike_top = pygame.Rect(p.x, p.y - (SPIKE_H - 1), p.w, SPIKE_H)
                    spike_bottom = pygame.Rect(p.x, p.y + p.h - 1, p.w, SPIKE_H)
                    if f_rect.colliderect(spike_top) or f_rect.colliderect(spike_bottom):
                        is_dead = True; death_kind = "spike"
                        death_from = (p.x + p.w / 2, p.y + p.h / 2)
                        break

        if is_dead:
            frog.start_death(death_kind if death_kind else "electric",
                             impact_from=death_from)
            spring_launched = False
            continue

        if not on_moving:
            frog.standing_platform = None
            if frog.vy >= 0:
                for p in platforms:
                    if p.broken: continue
                    if p.type == "spike": continue
                    if p.type == "danger": continue
                    plat_rect = pygame.Rect(p.x, p.y, p.w, p.h)
                    if f_rect.colliderect(plat_rect) and (frog.y + frog.h - frog.vy <= p.y + 8):
                        if p.type == "finish":
                            final_score = max(0, min(score, target_score))
                            completed_now = load_progress()
                            if level_num > completed_now:
                                save_progress(level_num)
                            result = await victory_animation(level_num, platforms,
                                                       bg_clouds, frog, final_score)
                            pygame.event.clear()
                            return result
                        if p.type == "cloud":
                            p.broken = True
                            p._spawn_particles()
                            break
                        frog.y, frog.vy, on_plat = p.y - frog.h, 0, True
                        frog.standing_platform = p
                        if p.type not in ("cloud", "break", "freeze", "fuel"):
                            last_safe_platform = p
                            last_safe_y = p.y
                        on_spring = False
                        if p.type == "spring":
                            if f_rect.colliderect(p.spring_hit_rect()):
                                on_spring = True
                                p.spring_anim = 1.0
                        if p.type == "spring" and on_spring:
                            if frog.spring_timer == 0:
                                frog.spring_timer = 200
                                frog.spring_platform = p
                                spring_launched = True
                        else:
                            if frog.spring_timer <= 0:
                                spring_launched = False
                        if p.type == "moving":
                            frog.standing_offset_x = frog.x - p.x
                        if p.type == "break":
                            p.is_stepped = True
                        if p.type == "freeze":
                            frog.freeze_timer = 1000
                        if w_down:
                            if not (p.type == "spring" and on_spring):
                                frog.jump()
                                if frog.ability_active:
                                    frog.jumps_left = 1
                        break

        if w_down and frog.ability_active and frog.jumps_left > 0 and not on_plat and frog.vy > -2:
            frog.jump()
            frog.jumps_left -= 1

        dy = 0
        if score < target_score and frog.y < H // 2:
            dy = int((H // 2 - frog.y) * 0.1)
            frog.y += dy
            total_rise += dy
            for p in platforms: p.y += dy

        current = compute_score(frog.y, total_rise)
        if current > score: score = current
        if score > target_score: score = target_score

        for c in bg_clouds: c.update(dy, bg_clouds)

        existing_top = min((pl.y for pl in platforms if not (
            (pl.type == "break" and pl.broken) or
            (pl.type == "cloud" and pl.broken) or
            pl.type == "finish")), default=-100)

        for p in platforms[:]:
            if p.type == "finish": continue
            if p.y > H + 20:
                platforms.remove(p)
                existing_top = spawn_level_platform(existing_top)
                continue
            if p.type == "cloud" and p.broken:
                if len(p.particles) == 0:
                    platforms.remove(p)
                    existing_top = spawn_level_platform(existing_top)
                continue
            if p.type == "break" and p.broken and p.alpha <= 0:
                platforms.remove(p)
                existing_top = spawn_level_platform(existing_top)
                continue

        if frog.y > H and not frog.dying:
            frog.start_death("fall")
            spring_launched = False
            continue

        screen.fill(BG)
        draw_sun(screen)
        for c in bg_clouds: c.draw(screen)
        for p in platforms: p.draw(screen)
        frog.draw(screen)

        show_text(f"Высота: {score} / {target_score} м", FONT, BLACK, 10, 10)
        if frog.ability_active:
            ab_txt = f"Двойной прыжок: {round(frog.ability_timer/1000, 1)}с"
            ab_col = ORANGE
        elif frog.cooldown > 0:
            ab_txt = f"Перезарядка К: {round(frog.cooldown/1000, 1)}с"
            ab_col = BLACK
        else:
            ab_txt = "Способность: К"
            ab_col = BLACK
        show_text(ab_txt, FONT, ab_col, 10, 30)
        pygame.display.flip()
        await asyncio.sleep(0)


# ======================== МИНИ ИГРЫ: МЕНЮ ========================
async def minigames_menu():
    title_font = pygame.font.SysFont("Arial", 34, bold=True)
    btn_font = pygame.font.SysFont("Arial", 19, bold=True)
    desc_font = pygame.font.SysFont("Arial", 14)
    cx = W // 2
    buttons = [
        Button("1. ЛАВА", cx, 170, w=280, h=58, base_color=(210, 80, 40)),
        Button("2. НОЧЬ", cx, 245, w=280, h=58, base_color=(60, 70, 120)),
        Button("3. ИСЧЕЗАЮЩИЕ", cx, 320, w=280, h=58, base_color=(120, 90, 160)),
    ]
    back_link = TextLink("назад", cx, H - 45, FONT, color=(0, 0, 0),
                         hover_color=(60, 60, 60))
    t = 0.0
    pygame.event.clear()
    while True:
        dt = clock.tick(60); t += dt / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return None
            for b in buttons: b.handle_event(event)
            back_link.handle_event(event)
        for b in buttons: b.update(dt)
        back_link.update(dt)
        for b in buttons:
            if b.clicked:
                b.clicked = False
                pygame.event.clear()
                return b.text
        if back_link.clicked:
            back_link.clicked = False
            return None
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(t * 15)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        title = title_font.render("МИНИ ИГРЫ", True, (30, 120, 40))
        screen.blit(title, title.get_rect(center=(cx, 80)))
        for b in buttons: b.draw(screen, btn_font)
        descs = [
            "Лава поднимается и ускоряется.",
            "Тёмная ночь: лампа гаснет — ищи топливо.",
            "Каждая платформа исчезает после шага.",
        ]
        for i, d in enumerate(descs):
            lbl = desc_font.render(d, True, (40, 40, 40))
            screen.blit(lbl, lbl.get_rect(center=(cx, 170 + i * 75 + 40)))
        back_link.draw(screen)
        hint = FONT.render("ESC — назад", True, (60, 60, 60))
        screen.blit(hint, hint.get_rect(center=(cx, H - 18)))
        pygame.display.flip()
        await asyncio.sleep(0)


# ======================== МИНИ ИГРЫ: ДВИЖОК ========================
def _minigame_spawn(platforms, score):
    alive = [pl for pl in platforms if not (
        (pl.type == "break" and pl.broken) or
        (pl.type == "cloud" and pl.broken))]
    if not alive:
        new_y = H - 200
        platforms.append(Platform(random.randint(0, W - 70), new_y, "normal"))
        return new_y
    existing_top = min(pl.y for pl in alive)
    y, _, _ = spawn_platform(existing_top, score, platforms, False, False)
    return y


def _draw_minigame_scene(surf, frog, platforms, bg_clouds,
                         bg_color, star_field, lava_y, lava_active,
                         lava_surface, is_dark, is_lava):
    surf.fill(bg_color)

    if is_dark:
        pass
    else:
        draw_sun(surf)
        for c in bg_clouds:
            c.draw(surf)

    for p in platforms:
        if is_lava and lava_active and not is_dark and p.y > lava_y - 4:
            continue
        p.draw(surf)

    frog.draw(surf)

    if is_lava and lava_active:
        top = int(lava_y)
        lava_surface.fill((0, 0, 0, 0))
        pygame.draw.rect(lava_surface, (220, 60, 20, 235),
                         (0, top, W, H - top))
        pygame.draw.rect(lava_surface, (255, 140, 30, 255),
                         (0, top, W, 6))
        tt = pygame.time.get_ticks() * 0.002
        for i in range(12):
            bx = (i * 53 + int(tt * 30)) % W
            by = top + 10 + int(8 * math.sin(tt * 2 + i))
            pygame.draw.circle(lava_surface, (255, 200, 80, 200), (bx, by), 3)
        surf.blit(lava_surface, (0, 0))

    if is_dark:
        for p in platforms:
            if p.type == "danger" and not p.broken:
                draw_danger_glow(surf, p)

        dark = pygame.Surface((W, H), pygame.SRCALPHA)
        dark.fill((0, 0, 0, 245))

        fuel_ratio = max(0.0, min(1.0, frog.lamp_fuel_seconds / MINIGAME_DARK_FUEL_SECONDS))
        if fuel_ratio <= 0.0:
            surf.blit(dark, (0, 0))
        else:
            radius = (MINIGAME_DARK_MIN_RADIUS
                      + (MINIGAME_DARK_FUEL_FULL_RADIUS - MINIGAME_DARK_MIN_RADIUS) * fuel_ratio)

            lcx, lcy = frog.get_lamp_pos()
            lamp_cx = int(lcx)
            lamp_cy = int(lcy)

            t_now = pygame.time.get_ticks() * 0.004
            radius_w = radius * (1.0 + 0.035 * math.sin(t_now * 1.6))

            steps = 22
            for i in range(steps, 0, -1):
                r = int(radius_w * i / steps)
                a = int(235 * (i / steps) ** 1.35)
                pygame.draw.circle(dark, (0, 0, 0, a), (lamp_cx, lamp_cy), r)
            pygame.draw.circle(dark, (0, 0, 0, 0), (lamp_cx, lamp_cy), int(radius_w * 0.5))

            for p in platforms:
                if p.type == "danger" and not p.broken:
                    ecx = p.x + p.w // 2
                    ecy = p.y + p.h // 2
                    tw = pygame.time.get_ticks() * 0.004
                    ew = 1.0 + 0.09 * math.sin(tw * 2.3) + 0.045 * math.sin(tw * 4.7)
                    oval_w = int((p.w + 62) * ew)
                    oval_h = int((p.h + 48) * ew)
                    if oval_w < 4 or oval_h < 4:
                        continue
                    cut = pygame.Surface((oval_w, oval_h), pygame.SRCALPHA)
                    csteps = 14
                    for i in range(csteps, 0, -1):
                        t = i / csteps
                        a = int(110 * (1 - t) ** 1.4)
                        if a <= 0:
                            continue
                        rx = int(oval_w * 0.5 * t)
                        ry = int(oval_h * 0.5 * t)
                        if rx <= 0 or ry <= 0:
                            continue
                        pygame.draw.ellipse(cut, (0, 0, 0, a),
                                            (oval_w // 2 - rx, oval_h // 2 - ry,
                                             rx * 2, ry * 2))
                    dark.blit(cut, (ecx - oval_w // 2, ecy - oval_h // 2),
                              special_flags=pygame.BLEND_RGBA_SUB)

            surf.blit(dark, (0, 0))

        draw_star_field_static(surf, star_field, pygame.time.get_ticks() * 0.001)
        draw_moon_and_light(surf)


async def _run_minigame_core(mode):
    is_dark = (mode == "dark")
    is_lava = (mode == "lava")
    is_vanish = (mode == "vanish")

    if is_dark:
        bg_color = (10, 12, 26)
        star_field = [(random.randint(0, W), random.randint(0, H),
                       random.choice([1, 1, 1, 2])) for _ in range(70)]
    else:
        bg_color = BG
        star_field = []

    frog = Frog()
    frog.x = W // 2 - frog.w // 2
    frog.y = H - 130
    frog.has_lamp = is_dark
    frog.lamp_fuel_seconds = MINIGAME_DARK_FUEL_SECONDS

    platforms = [Platform(W // 2 - 50, H - 100, "normal")]
    platforms[0].w = 100
    platforms[0]._ground_surface = None
    for i in range(8):
        platforms.append(Platform(random.randint(0, W - 70),
                                  H - 180 - i * 70, "normal"))

    if is_dark:
        bg_clouds = []
    else:
        bg_clouds = []
        for _ in range(6):
            bg_clouds.append(BackgroundCloud(bg_clouds))

    lava_y = float(H + 20)
    lava_active = is_lava
    lava_elapsed = 0.0
    lava_mult = MINIGAME_LAVA_START_MULT
    lava_speed = MINIGAME_LAVA_START_SPEED * (lava_mult ** MINIGAME_LAVA_GROWTH)
    lava_surface = pygame.Surface((W, H), pygame.SRCALPHA)

    vanished = set()
    next_fuel_at_meters = random.randint(MINIGAME_DARK_REFUEL_MIN_GAP,
                                        MINIGAME_DARK_REFUEL_MAX_GAP)

    score = 0
    paused = False
    respawns_left = MAX_RESPAWNS
    last_stood_platform = None
    last_stood_y = None
    spring_launched = False
    mg_high_score = load_minigame_high_score(mode)
    record_at_start = mg_high_score

    pause_btn_menu = Button("Выйти в меню", W // 2, H // 2 + 40,
                            w=240, h=52, base_color=(200, 80, 100))
    pause_btn_retry = Button("Заново", W // 2, H // 2 - 30,
                             w=240, h=52, base_color=(70, 170, 90))

    while True:
        dt = clock.tick(60)
        events = pygame.event.get()

        if paused:
            unpause = False
            for event in events:
                if event.type == pygame.QUIT:
                    save_high_score(high_score); pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    unpause = True
                else:
                    pause_btn_menu.handle_event(event)
                    pause_btn_retry.handle_event(event)
            if unpause:
                paused = False
                pause_btn_menu.reset_state()
                pause_btn_retry.reset_state()
                pygame.event.clear()
                continue
            pause_btn_menu.update(dt)
            pause_btn_retry.update(dt)
            _draw_minigame_scene(screen, frog, platforms, bg_clouds,
                                 bg_color, star_field, lava_y, lava_active,
                                 lava_surface, is_dark, is_lava)
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 150))
            screen.blit(ov, (0, 0))
            show_text("ПАУЗА", BIG_FONT, WHITE, W // 2, H // 2 - 90, center=True)
            pause_btn_retry.draw(screen, FONT)
            pause_btn_menu.draw(screen, FONT)
            pygame.display.flip()
            await asyncio.sleep(0)
            if pause_btn_menu.clicked:
                pause_btn_menu.reset_state(); pause_btn_retry.reset_state()
                pygame.event.clear()
                return "menu"
            if pause_btn_retry.clicked:
                pause_btn_menu.reset_state(); pause_btn_retry.reset_state()
                pygame.event.clear()
                return "retry"
            continue

        for event in events:
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = True
                elif event.key in (pygame.K_r, pygame.K_k):
                    frog.activate_ability()

        if frog.dying:
            frog.update_death(dt)
            frog.death_timer -= dt
            _draw_minigame_scene(screen, frog, platforms, bg_clouds,
                                 bg_color, star_field, lava_y, lava_active,
                                 lava_surface, is_dark, is_lava)
            if frog.death_kind in ("spike", "lava"):
                frog.draw_spike_hit(screen)
            elif frog.death_kind == "electric":
                frog.draw_electric_death(screen)
            show_text(f"Высота: {score} м", FONT,
                      WHITE if is_dark else BLACK, 10, 10)
            pygame.display.flip()
            await asyncio.sleep(0)
            if frog.death_timer <= 0:
                if respawns_left > 0:
                    r = await respawn_screen(score, respawns_left,
                                       prev_record=record_at_start,
                                       is_new_record=(score > record_at_start),
                                       dark=is_dark)
                else:
                    r = "skip"
                if r == "respawn":
                    respawns_left -= 1
                    frog = Frog()
                    frog.has_lamp = is_dark
                    frog.lamp_fuel_seconds = MINIGAME_DARK_FUEL_SECONDS
                    target = choose_respawn_target(platforms,
                                                   last_stood_platform,
                                                   last_stood_y)
                    if target is not None:
                        frog.x = target.x + target.w // 2 - frog.w // 2
                        frog.y = target.y - frog.h - 2
                        frog.vy = 0
                        frog.standing_platform = target
                        frog.standing_offset_x = frog.x - target.x
                    spring_launched = False
                    if is_lava:
                        if target is not None:
                            safe_lava_y = target.y + target.h + 120.0
                            if lava_y < safe_lava_y:
                                lava_y = safe_lava_y
                    next_fuel_at_meters = score + random.randint(
                        MINIGAME_DARK_REFUEL_MIN_GAP,
                        MINIGAME_DARK_REFUEL_MAX_GAP)
                    continue
                else:
                    if score > mg_high_score:
                        mg_high_score = score
                        save_minigame_high_score(mode, mg_high_score)
                    is_new_record = score > record_at_start
                    res = await game_over_screen(score, is_new_record,
                                           best_value=max(mg_high_score, score),
                                           dark=is_dark)
                    pygame.event.clear()
                    return "retry" if res == "restart" else "menu"
            continue

        frog.update_timers(dt)
        for p in platforms:
            p.update(dt)

        if is_lava:
            lava_elapsed += dt
            progress = min(1.0, lava_elapsed / MINIGAME_LAVA_RAMP_MS)
            real_mult = (MINIGAME_LAVA_START_MULT
                         + (MINIGAME_LAVA_MAX_MULT - MINIGAME_LAVA_START_MULT) * progress)
            lava_mult = real_mult
            lava_speed = MINIGAME_LAVA_START_SPEED * (real_mult ** MINIGAME_LAVA_GROWTH)
            lava_y -= lava_speed * (dt / 16.0)

        if is_dark:
            frog.lamp_fuel_seconds = max(0.0, frog.lamp_fuel_seconds - dt / 1000.0)

        if is_vanish:
            for p in list(platforms):
                fade = getattr(p, "vanish_fade", None)
                if fade is None:
                    continue
                p.vanish_fade = fade - dt * 255.0 / MINIGAME_VANISH_DELAY_MS
                p.alpha = max(0, int(p.vanish_fade))
                if p.vanish_fade <= 0:
                    vanished.add(p)
                    p.vanish_fade = None

        on_moving = False
        if frog.standing_platform is not None:
            sp = frog.standing_platform
            if sp not in platforms or sp.broken:
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
            elif sp.type == "moving":
                on_moving = True

        if on_moving:
            sp = frog.standing_platform
            keys = pygame.key.get_pressed()
            speed = 5 / 1.3 if frog.freeze_timer > 0 else 5
            if keys[pygame.K_a]: frog.standing_offset_x -= speed
            if keys[pygame.K_d]: frog.standing_offset_x += speed
            min_off = -frog.w + 4
            max_off = sp.w - 4
            if frog.standing_offset_x < min_off or frog.standing_offset_x > max_off:
                frog.x = sp.x + frog.standing_offset_x
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
                on_moving = False
                frog.move()
            else:
                frog.x = sp.x + frog.standing_offset_x
                frog.y = sp.y - frog.h
                frog.vy = 0
                if keys[pygame.K_w]:
                    frog.jump()
                    on_moving = False
        else:
            frog.move()

        w_down = pygame.key.get_pressed()[pygame.K_w]
        on_plat = False
        is_dead = False
        death_kind = None
        death_from = None
        f_rect = pygame.Rect(frog.x, frog.y, frog.w, frog.h)

        if not spring_launched:
            for p in platforms:
                if p.broken: continue
                if p.type == "danger":
                    R = p.RING_OFFSET
                    outer = pygame.Rect(p.x - R, p.y - R, p.w + 2*R, p.h + 2*R)
                    if f_rect.colliderect(outer):
                        is_dead = True; death_kind = "electric"; break
                elif p.type == "spike":
                    top = pygame.Rect(p.x, p.y - (SPIKE_H - 1), p.w, SPIKE_H)
                    bot = pygame.Rect(p.x, p.y + p.h - 1, p.w, SPIKE_H)
                    if f_rect.colliderect(top) or f_rect.colliderect(bot):
                        is_dead = True; death_kind = "spike"
                        death_from = (p.x + p.w / 2, p.y + p.h / 2)
                        break

        if is_lava and lava_active and not is_dead:
            if frog.y + frog.h >= lava_y:
                is_dead = True
                death_kind = "spike"
                death_from = (frog.x + frog.w / 2, lava_y)

        if is_dead:
            frog.start_death(death_kind if death_kind else "electric",
                             impact_from=death_from)
            spring_launched = False
            continue

        if not on_moving:
            frog.standing_platform = None
            if frog.vy >= 0:
                for p in platforms:
                    if p.broken: continue
                    if p.type in ("spike", "danger"): continue
                    pr = pygame.Rect(p.x, p.y, p.w, p.h)
                    if f_rect.colliderect(pr) and (frog.y + frog.h - frog.vy <= p.y + 8):
                        if p.type == "cloud":
                            p.broken = True
                            p._spawn_particles()
                            break
                        frog.y, frog.vy, on_plat = p.y - frog.h, 0, True
                        frog.standing_platform = p
                        if p.type == "fuel" and not p.fuel_taken:
                            p.fuel_taken = True
                            frog.lamp_fuel_seconds = min(
                                MINIGAME_DARK_FUEL_SECONDS,
                                frog.lamp_fuel_seconds + MINIGAME_DARK_REFUEL_SECONDS)
                        if p.type not in ("cloud", "break", "freeze", "fuel"):
                            last_stood_platform = p
                            last_stood_y = p.y
                        on_spring = False
                        if p.type == "spring":
                            if f_rect.colliderect(p.spring_hit_rect()):
                                on_spring = True
                                p.spring_anim = 1.0
                        if p.type == "spring" and on_spring:
                            if frog.spring_timer == 0:
                                frog.spring_timer = 200
                                frog.spring_platform = p
                                spring_launched = True
                        else:
                            if frog.spring_timer <= 0:
                                spring_launched = False
                        if p.type == "moving":
                            frog.standing_offset_x = frog.x - p.x
                        if p.type == "break":
                            p.is_stepped = True
                        if p.type == "freeze":
                            frog.freeze_timer = 1000
                        if is_vanish and p.type not in ("break",):
                            if getattr(p, "vanish_fade", None) is None:
                                p.vanish_fade = 255.0
                        if w_down:
                            if not (p.type == "spring" and on_spring):
                                frog.jump()
                                if frog.ability_active:
                                    frog.jumps_left = 1
                        break

        if (w_down and frog.ability_active and frog.jumps_left > 0
                and not on_plat and frog.vy > -2):
            frog.jump()
            frog.jumps_left -= 1

        dy = 0
        if frog.y < H // 2:
            dy = int((H // 2 - frog.y) * 0.1)
            frog.y += dy
            score += int(dy * 0.4)
            if score > mg_high_score:
                mg_high_score = score
                save_minigame_high_score(mode, mg_high_score)
            for p in platforms: p.y += dy
            if is_lava and lava_active:
                lava_y += dy

        if is_dark and score >= next_fuel_at_meters:
            existing_top = min((pl.y for pl in platforms
                                if not ((pl.type == "break" and pl.broken)
                                        or (pl.type == "cloud" and pl.broken))),
                               default=H - 400)
            # Тот же принцип, что у электрической платформы:
            # y на 35-50 px выше existing_top, x через find_free_x и is_danger_safe
            fuel_y = existing_top - random.randint(35, 50)
            fuel_x = find_free_x(platforms, fuel_y, 70, 15,
                                 extra_margin=DANGER_SAFE_GAP)
            if (fuel_x is not None
                    and is_danger_safe(fuel_x, fuel_y, platforms)
                    and count_type(platforms, "fuel") < MAX_DANGER_PLATFORMS):
                platforms.append(Platform(fuel_x, fuel_y, "fuel"))
            next_fuel_at_meters = score + random.randint(
                MINIGAME_DARK_REFUEL_MIN_GAP,
                MINIGAME_DARK_REFUEL_MAX_GAP)

        for c in bg_clouds:
            c.update(dy, bg_clouds if not is_dark else None)

        need_spawn = False
        for p in platforms[:]:
            if p.y > H + 20:
                platforms.remove(p)
                need_spawn = True
                continue
            if p.type == "cloud" and p.broken and len(p.particles) == 0:
                platforms.remove(p)
                need_spawn = True
                continue
            if p.type == "break" and p.broken and p.alpha <= 0:
                platforms.remove(p)
                need_spawn = True
                continue
            if is_vanish and p in vanished:
                platforms.remove(p)
                need_spawn = True
                continue

        if need_spawn:
            _minigame_spawn(platforms, score)

        if frog.y > H and not frog.dying:
            frog.start_death("fall")
            spring_launched = False
            continue

        _draw_minigame_scene(screen, frog, platforms, bg_clouds,
                             bg_color, star_field, lava_y, lava_active,
                             lava_surface, is_dark, is_lava)

        text_col = WHITE if is_dark else BLACK
        show_text(f"Высота: {score} м", FONT, text_col, 10, 10)
        show_text(f"Рекорд: {max(mg_high_score, score)} м", FONT, ORANGE, 10, 30)
        if is_lava:
            span = MINIGAME_LAVA_MAX_MULT - MINIGAME_LAVA_START_MULT
            display_mult = 1.0 + (lava_mult - MINIGAME_LAVA_START_MULT) / span * 29.0
            display_mult = max(1.0, min(30.0, display_mult))
            show_text(f"Скорость лавы: x{display_mult:.1f}",
                      FONT, (255, 120, 60), 10, 55)
        if is_vanish:
            show_text("Платформы исчезают!", FONT,
                      (200, 160, 255) if not is_dark else (220, 200, 255), 10, 55)
        if is_dark:
            fuel_ratio = max(0.0, min(1.0, frog.lamp_fuel_seconds / MINIGAME_DARK_FUEL_SECONDS))
            fuel_pct = int(round(fuel_ratio * 100))
            if fuel_pct > 20:
                col = (255, 220, 120)
            elif fuel_pct > 5:
                col = (255, 160, 60)
            else:
                col = (255, 90, 90)
            show_text(f"Топливо: {fuel_pct}%", FONT, col, 10, 55)
        pygame.display.flip()
        await asyncio.sleep(0)


async def minigame_lava():
    return await _run_minigame_core("lava")

async def minigame_dark():
    return await _run_minigame_core("dark")

async def minigame_vanish():
    return await _run_minigame_core("vanish")


async def main_menu():
    title_font = pygame.font.SysFont("Arial", 46, bold=True)
    btn_font   = pygame.font.SysFont("Arial", 24, bold=True)
    ht_font    = pygame.font.SysFont("Arial", 16, bold=True)
    cx = W // 2
    buttons = [
        Button("Играть",       cx, 215, base_color=(70, 170, 90)),
        Button("Уровни",       cx, 280, base_color=(90, 130, 200)),
        Button("Мини игры",    cx, 345, base_color=(200, 140, 60)),
        Button("Скины",        cx, 410, base_color=(170, 90, 180)),
        Button("Способности",  cx, 475, base_color=(200, 80, 100)),
    ]
    trophy_button = TrophyButton(28, 28, size=56)
    how_to_link = TextLink("как играть?", cx, 525, ht_font,
                           color=(0, 0, 0), hover_color=(60, 60, 60))
    all_clickables = buttons + [trophy_button, how_to_link]
    t = 0.0
    pygame.event.clear()
    while True:
        dt = clock.tick(60); t += dt / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return "quit"
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "quit"
            for b in all_clickables: b.handle_event(event)
        for b in all_clickables: b.update(dt)
        for b in buttons:
            if b.clicked:
                b.clicked = False
                if b.text == "Играть":
                    pygame.event.clear()
                    return "play"
                elif b.text == "Уровни":
                    while True:
                        level_num = await levels_screen()
                        if level_num is None:
                            break
                        current_level = level_num
                        while True:
                            result = await run_level(current_level)
                            if result == "complete":
                                completed = load_progress()
                                if current_level > completed:
                                    save_progress(current_level)
                                r2 = await level_complete_screen(current_level)
                                if r2 == "next":
                                    current_level += 1
                                    if current_level > WORKING_LEVELS: break
                                    continue
                                elif r2 == "levels": break
                                else: break
                            elif result == "next":
                                completed = load_progress()
                                if current_level > completed:
                                    save_progress(current_level)
                                current_level += 1
                                if current_level > WORKING_LEVELS: break
                                continue
                            elif result == "retry":
                                continue
                            elif result == "levels":
                                break
                            else:
                                break
                        if result == "menu":
                            break
                    for bb in buttons:
                        bb.hover_t = 0.0; bb.hovered = False
                        bb.pressed = False; bb.press_t = 0.0
                elif b.text == "Мини игры":
                    while True:
                        choice = await minigames_menu()
                        if choice is None:
                            break
                        if choice.startswith("1"):
                            runner = minigame_lava
                        elif choice.startswith("2"):
                            runner = minigame_dark
                        else:
                            runner = minigame_vanish
                        keep_going = True
                        while keep_going:
                            r = await runner()
                            if r == "retry":
                                continue
                            keep_going = False
                    for bb in buttons:
                        bb.hover_t = 0.0; bb.hovered = False
                        bb.pressed = False; bb.press_t = 0.0
        if trophy_button.clicked: trophy_button.clicked = False
        if how_to_link.clicked:
            how_to_link.clicked = False
            await how_to_play_screen()
            how_to_link.hover_t = 0.0
            how_to_link.hovered = False
        screen.fill(BG)
        draw_sun(screen)
        for i in range(5):
            x = (i * 110 + int(t * 15)) % (W + 120) - 60
            y = 60 + (i * 90) % 380
            pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
            pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
            pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        title = title_font.render("ПрыжкоМания", True, (30, 120, 40))
        screen.blit(title, title.get_rect(center=(cx, 100)))
        sub = FONT.render("Бесконечный прыгун", True, BLACK)
        screen.blit(sub, sub.get_rect(center=(cx, 145)))
        for b in buttons: b.draw(screen, btn_font)
        trophy_button.draw(screen, btn_font)
        ht_normal = ht_font.render("как играть?", True, (0, 0, 0))
        ht_hover = ht_font.render("как играть?", True, (60, 60, 60))
        ht_rect = ht_normal.get_rect(center=(cx, 525))
        if how_to_link.hover_t > 0.5:
            screen.blit(ht_hover, ht_rect.topleft)
            pygame.draw.line(screen, (60, 60, 60),
                             (ht_rect.left, ht_rect.bottom + 1),
                             (ht_rect.right, ht_rect.bottom + 1), 1)
        else:
            screen.blit(ht_normal, ht_rect.topleft)
        hint = FONT.render("ESC — выход", True, (60, 60, 60))
        screen.blit(hint, hint.get_rect(center=(cx, H - 20)))
        pygame.display.flip()
        await asyncio.sleep(0)


async def respawn_screen(score, respawns_left, show_high_score=True, prev_record=None,
                   is_new_record=False, dark=False):
    respawn_max_time = 5.0
    respawn_time_left = respawn_max_time
    respawn_button = Button("", W // 2, 410, w=220, h=70, base_color=(70, 170, 90))
    btn_big_font = pygame.font.SysFont("Arial", 22, bold=True)
    btn_small_font = pygame.font.SysFont("Arial", 13, italic=True)
    while True:
        dt = clock.tick(60)
        respawn_time_left -= dt / 1000.0
        if respawn_time_left < 0: respawn_time_left = 0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.event.clear()
                    return "skip"
            if respawn_time_left > 0: respawn_button.handle_event(event)
        if respawn_time_left > 0: respawn_button.update(dt)
        if respawn_button.clicked and respawn_time_left > 0:
            respawn_button.clicked = False
            pygame.event.clear()
            return "respawn"
        if respawn_time_left <= 0:
            pygame.event.clear()
            return "skip"
        if dark:
            _draw_dark_bg(screen)
        else:
            screen.fill(BG)
            draw_sun(screen)
            for i in range(5):
                x = (i * 110 + int(pygame.time.get_ticks() * 0.015)) % (W + 120) - 60
                y = 60 + (i * 90) % 380
                pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
                pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
                pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        _theme_text("ВОЗРОЖДЕНИЕ", BIG_FONT, dark, W // 2, 165,
                    light_color=(140, 220, 255), dark_color=(30, 115, 40))
        score_y = 230 if not show_high_score else 215
        _theme_text(f"Ваш счет: {score} м", FONT, dark, W // 2, score_y,
                    light_color=(220, 240, 255), dark_color=BLACK)
        if show_high_score:
            if prev_record is None:
                prev_record = high_score
            best_now = max(prev_record, score)
            if is_new_record:
                _theme_text(f"Прошлый рекорд: {prev_record} м", FONT, dark,
                            W // 2, 250,
                            light_color=(255, 220, 130), dark_color=ORANGE)
            else:
                _theme_text(f"Лучший рекорд: {best_now} м", FONT, dark,
                            W // 2, 250,
                            light_color=(255, 220, 130), dark_color=ORANGE)
        _theme_text("Хотите ли возродиться?", FONT, dark, W // 2, 290,
                    light_color=(220, 240, 255), dark_color=BLACK)
        bar_x = W // 2 - 120; bar_y = 320; bar_w = 240; bar_h = 18
        bg_bar_col = (40, 50, 80) if dark else (200, 200, 200)
        pygame.draw.rect(screen, bg_bar_col,
                         (bar_x, bar_y, bar_w, bar_h), border_radius=9)
        fill_w = int(bar_w * (respawn_time_left / respawn_max_time))
        if fill_w > 0:
            ratio = respawn_time_left / respawn_max_time
            r = int(70 + 180 * (1 - ratio))
            g = int(170 - 60 * (1 - ratio))
            b = int(90 - 40 * (1 - ratio))
            pygame.draw.rect(screen, (r, g, b),
                             (bar_x, bar_y, fill_w, bar_h), border_radius=9)
        border_c = (140, 200, 255) if dark else BLACK
        pygame.draw.rect(screen, border_c,
                         (bar_x, bar_y, bar_w, bar_h), 2, border_radius=9)
        _theme_text(f"{respawn_time_left:.1f} сек", FONT, dark, W // 2, 353,
                    light_color=(200, 230, 255), dark_color=BLACK)
        respawn_button.draw(screen, FONT)
        big_lbl = btn_big_font.render("Бесплатно", True, WHITE)
        screen.blit(big_lbl, big_lbl.get_rect(center=(W // 2, 400)))
        small_lbl = btn_small_font.render("пока что..", True, (230, 230, 230))
        screen.blit(small_lbl, small_lbl.get_rect(center=(W // 2, 428)))
        _theme_text("ESC — пропустить", FONT, dark, W // 2, H - 40,
                    light_color=(160, 200, 240), dark_color=(80, 80, 80))
        pygame.display.flip()
        await asyncio.sleep(0)


async def game_over_screen(score, is_new_record=False, best_value=None, dark=False):
    global high_score
    if best_value is None:
        if score > high_score:
            high_score = score
            save_high_score(high_score)
        best_value = max(high_score, score)

    confetti_list = []
    record_text_y = H // 2
    if is_new_record:
        spawn_confetti_burst(confetti_list, W // 2, record_text_y, count=90)

    while True:
        dt = clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    pygame.event.clear()
                    return "restart"
                if event.key == pygame.K_ESCAPE:
                    pygame.event.clear()
                    return "menu"
        if dark:
            _draw_dark_bg(screen)
        else:
            screen.fill(BG)
            draw_sun(screen)
            for i in range(5):
                x = (i * 110 + int(pygame.time.get_ticks() * 0.015)) % (W + 120) - 60
                y = 60 + (i * 90) % 380
                pygame.draw.ellipse(screen, CLOUD, (x, y, 90, 38))
                pygame.draw.ellipse(screen, CLOUD, (x + 30, y - 14, 70, 42))
                pygame.draw.ellipse(screen, CLOUD, (x + 55, y + 6, 60, 30))
        _theme_text("ИГРА ОКОНЧЕНА", BIG_FONT, dark, W // 2, H // 2 - 90,
                    light_color=(255, 150, 150), dark_color=BLACK)
        _theme_text(f"Ваш счет: {score} м", FONT, dark, W // 2, H // 2 - 30,
                    light_color=(220, 240, 255), dark_color=BLACK)
        if is_new_record:
            _theme_text(f"Новый рекорд {best_value} м!", FONT, dark,
                        W // 2, record_text_y,
                        light_color=(255, 230, 130), dark_color=ORANGE)
        else:
            _theme_text(f"Лучший рекорд: {best_value} м", FONT, dark,
                        W // 2, record_text_y,
                        light_color=(255, 230, 130), dark_color=ORANGE)
        _theme_text("ПРОБЕЛ — начать заново", FONT, dark, W // 2, H // 2 + 50,
                    light_color=(130, 230, 150), dark_color=GREEN)
        _theme_text("ESC — в меню", FONT, dark, W // 2, H // 2 + 80,
                    light_color=(160, 200, 240), dark_color=GRAY)
        update_and_draw_confetti(confetti_list, dt, screen)
        pygame.display.flip()
        await asyncio.sleep(0)


def _overlaps_vertical(p, y, h, margin=6):
    return not (y + h + margin < p.y or y > p.y + p.h + margin)


def find_free_x(platforms, y, w, h, tries=40, extra_margin=4):
    candidates = list(range(0, max(1, W - w + 1), 5))
    random.shuffle(candidates)
    for x in candidates[:tries]:
        new_rect = pygame.Rect(x, y, w, h)
        ok = True
        for p in platforms:
            if p.broken: continue
            if not _overlaps_vertical(p, y, h, margin=extra_margin): continue
            if new_rect.colliderect(pygame.Rect(p.x, p.y, p.w, p.h)):
                ok = False; break
        if ok: return x
    return None


def is_danger_safe(x, y, platforms, w=70, h=15, min_gap=DANGER_SAFE_GAP,
                   horiz_margin=25):
    for p in platforms:
        if p.broken: continue
        if x + w + horiz_margin <= p.x or x >= p.x + p.w + horiz_margin:
            continue
        if p.y >= y + h: gap = p.y - (y + h)
        elif y >= p.y + p.h: gap = y - (p.y + p.h)
        else: gap = 0
        if gap < min_gap: return False
    return True


def count_type(platforms, p_type):
    return sum(1 for p in platforms if p.type == p_type and not p.broken)


def total_particles(platforms):
    return sum(len(p.particles) for p in platforms if p.type == "cloud")


def spawn_platform(existing_top, score, platforms, next_gap_reduced=False, next_must_be_normal=False):
    if next_gap_reduced:
        min_gap, max_gap = platform_gap_range(score)
        min_gap = int(min_gap * 0.45)
        max_gap = int(max_gap * 0.55)
        max_gap = min(max_gap, 50)
        min_gap = min(min_gap, max_gap - 5)
        next_gap_reduced = False
    else:
        min_gap, max_gap = platform_gap_range(score)

    x = random.randint(0, W - 70)
    y = existing_top - random.randint(min_gap, max_gap)

    if next_must_be_normal:
        base_type = "normal"
        was_replace = False
        next_must_be_normal = False
    else:
        if score >= MOVING_START_SCORE and random.random() < MOVING_REPLACE_CHANCE:
            base_type = "moving"
        else:
            base_type = "break" if (score >= 500 and random.random() < 0.175) else "normal"
        was_replace = False
        if (base_type == "normal"
                and random.random() < freeze_replace_chance(score)):
            base_type = "freeze"
            was_replace = True

    moving_mr = None; moving_base = None
    if base_type == "moving":
        plat_w = 70
        moving_base = random.randint(0, W - plat_w)
        max_left = moving_base
        max_right = (W - plat_w) - moving_base
        max_mr = min(max_left, max_right)
        if max_mr < MOVING_RANGE_MIN:
            base_type = "normal"
        else:
            moving_mr = random.randint(MOVING_RANGE_MIN, max_mr)

    new_plat = Platform(x, y, base_type, move_speed_mult=moving_speed_mult(score))
    if base_type == "moving":
        new_plat.base_x = moving_base
        new_plat.move_range = moving_mr
        new_plat.move_phase = random.uniform(0, 2 * math.pi)
        frac = _triangle_frac(new_plat.move_phase)
        new_plat.x = new_plat.base_x + (frac * 2 - 1) * new_plat.move_range
        new_plat.prev_x = new_plat.x
    if base_type == "normal" and score >= 1500 and random.random() < SPRING_CHANCE:
        new_plat.type = "spring"
        new_plat.spring_x = random.randint(6, new_plat.w - 6 - new_plat.spring_w)
        new_plat.spring_hit_pad = SPRING_HIT_PAD
    platforms.append(new_plat)

    if was_replace:
        next_gap_reduced = True
        next_must_be_normal = True

    spec_y_base = y - random.randint(35, 50)

    next_normal = None
    for pl in platforms:
        if pl.type in ("normal", "spring", "moving") and not pl.broken:
            if pl.y < y and (next_normal is None or pl.y > next_normal.y):
                next_normal = pl

    def blocks_path(ox):
        if next_normal is None: return False
        horiz_close = not (ox + 70 <= next_normal.x or ox >= next_normal.x + next_normal.w)
        vert_close = abs(spec_y_base - next_normal.y) < 90
        return horiz_close and vert_close

    if (random.random() < danger_chance(score)
            and count_type(platforms, "danger") < MAX_DANGER_PLATFORMS):
        ex = find_free_x(platforms, spec_y_base, 70, 15, extra_margin=DANGER_SAFE_GAP)
        if ex is not None and is_danger_safe(ex, spec_y_base, platforms) and not blocks_path(ex):
            platforms.append(Platform(ex, spec_y_base, "danger"))

    if (random.random() < spike_chance(score)
            and count_type(platforms, "spike") < MAX_DANGER_PLATFORMS):
        spx = find_free_x(platforms, spec_y_base, 70, 15, extra_margin=DANGER_SAFE_GAP)
        if spx is not None and is_danger_safe(spx, spec_y_base, platforms) and not blocks_path(spx):
            platforms.append(Platform(spx, spec_y_base, "spike"))

    spawned = False
    if score >= 2000 and random.random() < 0.18:
        sx = find_free_x(platforms, spec_y_base, 70, 15)
        if sx is None: sx = random.randint(0, W - 70)
        platforms.append(Platform(sx, spec_y_base, "freeze"))
        spawned = True
    if (not spawned and score >= 1500 and random.random() < 0.10
            and count_type(platforms, "cloud") < MAX_CLOUD_PLATFORMS
            and total_particles(platforms) < MAX_PARTICLES_TOTAL):
        sx = find_free_x(platforms, spec_y_base, 70, 15)
        if sx is None: sx = random.randint(0, W - 70)
        platforms.append(Platform(sx, spec_y_base, "cloud"))
    return y, next_gap_reduced, next_must_be_normal


async def main():
    global high_score
    record_at_start = high_score
    frog = Frog()
    platforms = [Platform(W // 2 - 50, H - 100, "normal")]
    platforms[0].w = 100
    platforms[0]._ground_surface = None
    for i in range(8):
        platforms.append(Platform(random.randint(0, W - 70), H - 180 - (i * 70), "normal"))
    bg_clouds = []
    for _ in range(6):
        bg_clouds.append(BackgroundCloud(bg_clouds))
    score, paused = 0, False
    spring_launched = False
    last_stood_platform = None
    last_stood_y = None
    respawns_left = MAX_RESPAWNS
    pause_button = Button("Выйти в меню", W // 2, H // 2 + 60,
                          w=240, h=55, base_color=(200, 80, 100))
    next_gap_reduced = False
    next_must_be_normal = False
    while True:
        dt = clock.tick(60)
        events = pygame.event.get()
        if paused:
            unpause = False
            for event in events:
                if event.type == pygame.QUIT:
                    if score > high_score: high_score = score
                    save_high_score(high_score); pygame.quit(); sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    unpause = True
                else:
                    pause_button.handle_event(event)
            if unpause:
                paused = False
                pause_button.reset_state()
                pygame.event.clear()
                continue
            pause_button.update(dt)
            screen.fill(BG)
            draw_sun(screen)
            for c in bg_clouds: c.draw(screen)
            for p in platforms: p.draw(screen)
            frog.draw(screen)
            show_text(f"Высота: {score} м", FONT, BLACK, 10, 10)
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 140))
            screen.blit(ov, (0, 0))
            show_text("ПАУЗА", BIG_FONT, WHITE, W // 2, H // 2 - 60, center=True)
            show_text("ESC — продолжить", FONT, WHITE, W // 2, H // 2 - 10, center=True)
            pause_button.draw(screen, FONT)
            pygame.display.flip()
            await asyncio.sleep(0)
            if pause_button.clicked:
                if score > high_score: high_score = score
                save_high_score(high_score)
                pause_button.reset_state()
                pygame.event.clear()
                return "menu"
            continue
        for event in events:
            if event.type == pygame.QUIT:
                if score > high_score: high_score = score
                save_high_score(high_score); pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: paused = True
                elif event.key in [pygame.K_r, pygame.K_k]:
                    frog.activate_ability()
        if frog.dying:
            frog.update_death(dt); frog.death_timer -= dt
            for c in bg_clouds: c.update(0, bg_clouds)
            screen.fill(BG)
            draw_sun(screen)
            for c in bg_clouds: c.draw(screen)
            for p in platforms: p.draw(screen)
            if frog.death_kind == "spike":
                frog.draw_spike_hit(screen)
            elif frog.death_kind == "electric":
                frog.draw_electric_death(screen)
            else:
                frog.draw(screen)
            show_text(f"Высота: {score} м", FONT, BLACK, 10, 10)
            show_text(f"Рекорд: {max(high_score, score)} м", FONT, ORANGE, 10, 30)
            pygame.display.flip()
            await asyncio.sleep(0)
            if frog.death_timer <= 0:
                if respawns_left > 0:
                    respawn_result = await respawn_screen(score, respawns_left,
                                                   prev_record=record_at_start,
                                                   is_new_record=(score > record_at_start))
                else:
                    respawn_result = "skip"
                if respawn_result == "respawn":
                    respawns_left -= 1
                    frog = Frog()
                    target_plat = choose_respawn_target(platforms, last_stood_platform, last_stood_y)
                    if target_plat is not None:
                        frog.x = target_plat.x + target_plat.w // 2 - frog.w // 2
                        frog.y = target_plat.y - frog.h - 2
                        frog.vy = 0
                        frog.standing_platform = target_plat
                        frog.standing_offset_x = frog.x - target_plat.x
                    spring_launched = False
                    continue
                else:
                    is_new_record = score > record_at_start
                    result = await game_over_screen(score, is_new_record)
                    if result == "restart":
                        pygame.event.clear()
                        return "restart"
                    else:
                        pygame.event.clear()
                        return "menu"
            continue
        frog.update_timers(dt)
        for p in platforms: p.update(dt)
        on_moving = False
        if frog.standing_platform is not None:
            sp = frog.standing_platform
            if sp not in platforms or sp.broken:
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
            elif sp.type == "moving":
                on_moving = True
        if on_moving:
            sp = frog.standing_platform
            keys = pygame.key.get_pressed()
            speed = 5
            if frog.freeze_timer > 0: speed = 5 / 1.3
            if keys[pygame.K_a]: frog.standing_offset_x -= speed
            if keys[pygame.K_d]: frog.standing_offset_x += speed
            min_off = -frog.w + 4
            max_off = sp.w - 4
            if frog.standing_offset_x < min_off or frog.standing_offset_x > max_off:
                frog.x = sp.x + frog.standing_offset_x
                frog.standing_platform = None
                frog.standing_offset_x = 0.0
                on_moving = False
                frog.move()
            else:
                frog.x = sp.x + frog.standing_offset_x
                frog.y = sp.y - frog.h
                frog.vy = 0
                if keys[pygame.K_w]:
                    frog.jump()
                    on_moving = False
        else:
            frog.move()
        w_down = pygame.key.get_pressed()[pygame.K_w]
        on_plat = False
        is_dead = False; death_kind = None; death_from = None
        f_rect = pygame.Rect(frog.x, frog.y, frog.w, frog.h)
        if not spring_launched:
            for p in platforms:
                if p.broken: continue
                if p.type == "danger":
                    R = p.RING_OFFSET
                    outer = pygame.Rect(p.x - R, p.y - R, p.w + 2 * R, p.h + 2 * R)
                    if f_rect.colliderect(outer):
                        is_dead = True; death_kind = "electric"; break
                elif p.type == "spike":
                    spike_top = pygame.Rect(p.x, p.y - (SPIKE_H - 1), p.w, SPIKE_H)
                    spike_bottom = pygame.Rect(p.x, p.y + p.h - 1, p.w, SPIKE_H)
                    if f_rect.colliderect(spike_top) or f_rect.colliderect(spike_bottom):
                        is_dead = True; death_kind = "spike"
                        death_from = (p.x + p.w / 2, p.y + p.h / 2)
                        break
        if is_dead:
            frog.start_death(death_kind if death_kind else "electric",
                             impact_from=death_from)
            spring_launched = False
            continue
        if not on_moving:
            frog.standing_platform = None
            if frog.vy >= 0:
                for p in platforms:
                    if p.broken: continue
                    if p.type == "spike": continue
                    if p.type == "danger": continue
                    plat_rect = pygame.Rect(p.x, p.y, p.w, p.h)
                    if f_rect.colliderect(plat_rect) and (frog.y + frog.h - frog.vy <= p.y + 8):
                        if p.type == "cloud":
                            p.broken = True
                            p._spawn_particles()
                            last_stood_platform = p
                            last_stood_y = p.y
                            break
                        frog.y, frog.vy, on_plat = p.y - frog.h, 0, True
                        frog.standing_platform = p
                        last_stood_platform = p
                        last_stood_y = p.y
                        on_spring = False
                        if p.type == "spring":
                            spring_hit = p.spring_hit_rect()
                            if f_rect.colliderect(spring_hit):
                                on_spring = True
                                p.spring_anim = 1.0
                        if p.type == "spring" and on_spring:
                            if frog.spring_timer == 0:
                                frog.spring_timer = 200
                                frog.spring_platform = p
                                spring_launched = True
                        else:
                            if frog.spring_timer <= 0:
                                spring_launched = False
                        if p.type == "moving":
                            frog.standing_offset_x = frog.x - p.x
                        if p.type == "break":
                            p.is_stepped = True
                        if p.type == "freeze":
                            frog.freeze_timer = 1000
                        if w_down:
                            if p.type == "spring" and on_spring:
                                pass
                            else:
                                frog.jump()
                                if frog.ability_active:
                                    frog.jumps_left = 1
                        break
        if w_down and frog.ability_active and frog.jumps_left > 0 and not on_plat and frog.vy > -2:
            frog.jump()
            frog.jumps_left -= 1
        dy = 0
        if frog.y < H // 2:
            dy = int((H // 2 - frog.y) * 0.1)
            frog.y += dy
            score += int(dy * 0.4)
            if score > high_score: high_score = score
            for p in platforms: p.y += dy
        for c in bg_clouds: c.update(dy, bg_clouds)
        existing_top = min((pl.y for pl in platforms if not (
            (pl.type == "break" and pl.broken) or
            (pl.type == "cloud" and pl.broken))), default=-100)
        for p in platforms[:]:
            if p.y > H + 20:
                platforms.remove(p)
                existing_top, next_gap_reduced, next_must_be_normal = spawn_platform(
                    existing_top, score, platforms, next_gap_reduced, next_must_be_normal)
                continue
            if p.type == "cloud" and p.broken:
                if len(p.particles) == 0:
                    platforms.remove(p)
                    existing_top, next_gap_reduced, next_must_be_normal = spawn_platform(
                        existing_top, score, platforms, next_gap_reduced, next_must_be_normal)
                continue
            if p.type == "break" and p.broken and p.alpha <= 0:
                platforms.remove(p)
                existing_top, next_gap_reduced, next_must_be_normal = spawn_platform(
                    existing_top, score, platforms, next_gap_reduced, next_must_be_normal)
                continue
        if frog.y > H and not frog.dying:
            frog.start_death("fall")
            spring_launched = False
            continue
        screen.fill(BG)
        draw_sun(screen)
        for c in bg_clouds: c.draw(screen)
        for p in platforms: p.draw(screen)
        frog.draw(screen)
        show_text(f"Высота: {score} м", FONT, BLACK, 10, 10)
        show_text(f"Рекорд: {max(high_score, score)} м", FONT, ORANGE, 10, 30)
        if frog.ability_active:
            ab_txt = f"Двойной прыжок: {round(frog.ability_timer/1000, 1)}с"
            ab_col = ORANGE
        elif frog.cooldown > 0:
            ab_txt = f"Перезарядка К: {round(frog.cooldown/1000, 1)}с"
            ab_col = BLACK
        else:
            ab_txt = "Способность: К"
            ab_col = BLACK
        show_text(ab_txt, FONT, ab_col, 10, 55)
        pygame.display.flip()
        await asyncio.sleep(0)


# ======================== ТОЧКА ВХОДА ========================
async def app_main():
    while True:
        action = await main_menu()
        if action == "quit":
            save_high_score(high_score)
            pygame.quit()
            return
        elif action == "play":
            while True:
                result = await main()
                if result == "restart":
                    continue
                else:
                    break


if __name__ == "__main__":
    asyncio.run(app_main())
